export function openMail(href: string) {
  const link = document.createElement("a");
  link.href = href;
  link.rel = "noopener";
  link.style.display = "none";
  document.body.appendChild(link);
  link.click();
  link.remove();
}

export function pingNotification(title: string, body: string) {
  if (typeof Notification === "undefined" || Notification.permission !== "granted") return;
  try {
    new Notification(title, { body });
  } catch {
    /* notification blocked or needs a service worker */
  }
}

export function vibrateAlert() {
  try {
    navigator.vibrate?.([28, 36, 28]);
  } catch {
    /* device without vibration */
  }
}

export async function requestScreenNotifications() {
  if (typeof Notification === "undefined") return "unsupported" as const;
  return Notification.requestPermission();
}
