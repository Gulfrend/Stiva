import { useCallback, useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import * as Dialog from "@radix-ui/react-dialog";
import {
  Bell,
  Check,
  ChevronLeft,
  Copy,
  Mail,
  MapPin,
  Minus,
  Package,
  Pencil,
  Plus,
  ScanLine,
  Share2,
  Trash2,
  Users,
} from "lucide-react";
import { signOut } from "@/lib/auth/client";
import { hasGateSessionMarker } from "@/lib/auth/gate-session-marker";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import {
  ackAlerts,
  createWarehouse,
  deleteItem,
  deleteWarehouse,
  joinWarehouse,
  leaveWarehouse,
  listAlerts,
  listItems,
  listMembers,
  listMovements,
  listWarehouses,
  lookupItem,
  recordMove,
  saveItem,
  updateNotifyEmail,
  type Item,
  type Member,
  type Movement,
  type StockAlert,
  type StockChange,
  type Warehouse,
} from "@/lib/stiva/api";
import {
  AUTO_MAIL_KEY,
  UNITS,
  WAREHOUSE_KEY,
  buildMailto,
  formatJoin,
  formatQty,
  formatQtyInput,
  formatWhen,
  isLow,
  markAlertsSeen,
  parseQty,
  readSeen,
} from "@/lib/stiva/format";
import { openMail, pingNotification, requestScreenNotifications, vibrateAlert } from "@/components/stiva/notify";
import { Scanner } from "@/components/stiva/scanner";

type Tab = "stock" | "team";
type Kind = "prelievo" | "carico";
type Overlay =
  | null
  | { type: "scan" }
  | { type: "edit"; itemId: string | null; presetCode?: string }
  | { type: "detail"; itemId: string }
  | { type: "move"; itemId: string; kind: Kind }
  | { type: "log"; itemId: string | null };

function messageOf(error: unknown) {
  if (error instanceof Error) {
    return error.message === "Unauthorized" ? "Sessione scaduta. Entra di nuovo." : error.message;
  }
  return "Qualcosa non ha funzionato.";
}

function StatusPill({ item }: { item: Item }) {
  if (item.qty <= 0) return <span className="pill pill-danger">Esaurito</span>;
  if (isLow(item.qty, item.min_qty)) return <span className="pill pill-warn">Sotto soglia</span>;
  return <span className="pill pill-ok">Ok</span>;
}

function QrImage({ code }: { code: string }) {
  const [src, setSrc] = useState<string | null>(null);
  useEffect(() => {
    let live = true;
    void import("qrcode")
      .then((mod) =>
        mod.toDataURL(code, {
          margin: 1,
          width: 320,
          color: { dark: "#1c1915", light: "#fffcf7" },
        }),
      )
      .then((url) => {
        if (live) setSrc(url);
      })
      .catch(() => {
        if (live) setSrc(null);
      });
    return () => {
      live = false;
    };
  }, [code]);
  if (!src) {
    return <div className="grid h-52 w-52 place-items-center bg-chip text-sm text-muted">QR</div>;
  }
  return <img className="h-52 w-52" src={src} width={208} height={208} alt={`Codice QR ${code}`} />;
}

export function StivaApp() {
  const qc = useQueryClient();
  const user = useCurrentUser();
  const [ready, setReady] = useState(false);
  const [warehouseId, setWarehouseId] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>("stock");
  const [overlay, setOverlay] = useState<Overlay>(null);
  const [query, setQuery] = useState("");
  const [onlyLow, setOnlyLow] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [forced, setForced] = useState<StockAlert[]>([]);
  const [defer, setDefer] = useState(false);
  const [autoMail, setAutoMail] = useState(true);
  const [perm, setPerm] = useState<NotificationPermission | "unsupported">("default");
  const picked = useRef(false);
  const booted = useRef(false);

  useEffect(() => {
    setWarehouseId(localStorage.getItem(WAREHOUSE_KEY));
    setAutoMail(localStorage.getItem(AUTO_MAIL_KEY) !== "0");
    setPerm(typeof Notification === "undefined" ? "unsupported" : Notification.permission);
    setReady(true);
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 2800);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const warehouses = useQuery({
    queryKey: ["warehouses"],
    queryFn: () => listWarehouses(),
  });

  const chooseWarehouse = useCallback((id: string | null) => {
    picked.current = true;
    setWarehouseId(id);
    setOverlay(null);
    setTab("stock");
    setQuery("");
    if (id) localStorage.setItem(WAREHOUSE_KEY, id);
    else localStorage.removeItem(WAREHOUSE_KEY);
  }, []);

  useEffect(() => {
    if (!ready || !warehouses.data || booted.current) return;
    booted.current = true;
    if (warehouseId && warehouses.data.some((row) => row.id === warehouseId)) return;
    if (warehouses.data[0]) chooseWarehouse(warehouses.data[0].id);
  }, [chooseWarehouse, ready, warehouseId, warehouses.data]);

  useEffect(() => {
    if (!ready || !warehouses.data || !warehouseId || !booted.current) return;
    if (warehouses.data.some((row) => row.id === warehouseId)) return;
    chooseWarehouse(warehouses.data[0]?.id ?? null);
  }, [chooseWarehouse, ready, warehouseId, warehouses.data]);

  const remember = useCallback(
    (row: Warehouse) => {
      qc.setQueryData<Warehouse[]>(["warehouses"], (prev) => {
        const list = prev ?? [];
        if (list.some((item) => item.id === row.id)) return list;
        return [row, ...list];
      });
      chooseWarehouse(row.id);
    },
    [chooseWarehouse, qc],
  );

  const warehouse = warehouses.data?.find((row) => row.id === warehouseId) ?? null;

  const itemsQuery = useQuery({
    queryKey: ["items", warehouseId],
    enabled: Boolean(warehouseId),
    queryFn: () => listItems({ data: { warehouseId: warehouseId! } }),
    refetchInterval: 8000,
  });

  const alertsQuery = useQuery({
    queryKey: ["alerts", warehouseId],
    enabled: Boolean(warehouseId),
    queryFn: () => listAlerts({ data: { warehouseId: warehouseId! } }),
    refetchInterval: 8000,
  });

  const moveItemId =
    overlay?.type === "detail" ? overlay.itemId : overlay?.type === "log" ? overlay.itemId : undefined;

  const movesQuery = useQuery({
    queryKey: ["moves", warehouseId, moveItemId ?? "all"],
    enabled: Boolean(warehouseId) && moveItemId !== undefined,
    queryFn: () =>
      listMovements({
        data: { warehouseId: warehouseId!, itemId: moveItemId ?? null },
      }),
  });

  const membersQuery = useQuery({
    queryKey: ["members", warehouseId],
    enabled: Boolean(warehouseId) && (tab === "team" || overlay?.type === "detail"),
    queryFn: () => listMembers({ data: { warehouseId: warehouseId! } }),
  });

  const refresh = useCallback(async () => {
    await Promise.all([
      qc.invalidateQueries({ queryKey: ["items", warehouseId] }),
      qc.invalidateQueries({ queryKey: ["alerts", warehouseId] }),
      qc.invalidateQueries({ queryKey: ["moves", warehouseId] }),
      qc.invalidateQueries({ queryKey: ["warehouses"] }),
      qc.invalidateQueries({ queryKey: ["members", warehouseId] }),
    ]);
  }, [qc, warehouseId]);

  const forget = useCallback(
    (id: string) => {
      const list = (qc.getQueryData<Warehouse[]>(["warehouses"]) ?? []).filter((row) => row.id !== id);
      qc.setQueryData(["warehouses"], list);
      chooseWarehouse(list[0]?.id ?? null);
      void refresh();
    },
    [chooseWarehouse, qc, refresh],
  );

  const publish = useCallback(
    (result: StockChange, quiet: string) => {
      if (result.threshold_hit && result.alert) {
        setForced((prev) => [result.alert!, ...prev.filter((row) => row.id !== result.alert!.id)]);
        setDefer(false);
        markAlertsSeen([result.alert.id]);
        vibrateAlert();
        pingNotification(`Sotto soglia · ${result.alert.item_code}`, result.alert.message);
        if (autoMail && result.mailto) openMail(result.mailto);
        setToast("Soglia minima raggiunta");
      } else {
        setToast(quiet);
      }
      void refresh();
    },
    [autoMail, refresh],
  );

  useEffect(() => {
    const incoming = alertsQuery.data;
    if (!incoming?.length) return;
    const seen = readSeen();
    const fresh = incoming.filter((alert) => !seen.has(alert.id));
    if (!fresh.length) return;
    markAlertsSeen(fresh.map((alert) => alert.id));
    setDefer(false);
    const title =
      fresh.length === 1 ? `Sotto soglia · ${fresh[0].item_code}` : `${fresh.length} articoli sotto soglia`;
    pingNotification(title, fresh.map((alert) => alert.message).join("\n"));
  }, [alertsQuery.data]);

  const alerts = useMemo(() => {
    const merged = [...forced, ...(alertsQuery.data ?? [])];
    return merged.filter((alert, index) => merged.findIndex((row) => row.id === alert.id) === index);
  }, [alertsQuery.data, forced]);

  const items = itemsQuery.data ?? [];
  const filtered = items.filter((item) => {
    if (onlyLow && !isLow(item.qty, item.min_qty)) return false;
    const hay = `${item.code} ${item.name} ${item.location}`.toLowerCase();
    return hay.includes(query.trim().toLowerCase());
  });
  const lowCount = items.filter((item) => isLow(item.qty, item.min_qty)).length;
  const showAlert = alerts.length > 0 && !defer && overlay?.type !== "scan";
  const mailHref = buildMailto(
    alerts.flatMap((alert) => alert.recipients.split(",")),
    alerts.map((alert) => ({
      code: alert.item_code,
      name: alert.item_name,
      qty: alert.qty_after,
      min: alert.min_qty,
      unit: alert.unit,
    })),
  );

  const onScan = useCallback(
    async (code: string) => {
      if (!warehouseId) return;
      setOverlay(null);
      try {
        const found = await lookupItem({ data: { warehouseId, code } });
        if (found.item) setOverlay({ type: "move", itemId: found.item.id, kind: "prelievo" });
        else {
          setToast(`Nessun articolo ${code}. Creane uno.`);
          setOverlay({ type: "edit", itemId: null, presetCode: code });
        }
      } catch (error) {
        setToast(messageOf(error));
      }
    },
    [warehouseId],
  );

  const ack = useMutation({
    mutationFn: () => ackAlerts({ data: { warehouseId: warehouseId! } }),
    onSuccess: () => {
      setForced([]);
      void refresh();
    },
  });

  if (!ready || warehouses.isLoading) {
    return (
      <main className="grid min-h-screen place-items-center">
        <div>
          <p className="eyebrow">Magazzino</p>
          <h1 className="wordmark text-3xl">Stiva</h1>
        </div>
      </main>
    );
  }

  if (warehouses.isError) {
    return (
      <main className="mx-auto flex min-h-screen w-full max-w-xl flex-col justify-center gap-4 px-5">
        <h1 className="text-3xl font-semibold tracking-tight">Stiva</h1>
        <p className="note note-danger" role="alert">
          {messageOf(warehouses.error)}
        </p>
        <button type="button" className="btn btn-primary" onClick={() => void warehouses.refetch()}>
          Riprova
        </button>
      </main>
    );
  }

  const liveItem = (id: string) => items.find((item) => item.id === id) ?? null;

  return (
    <div className="app-frame">
      {overlay?.type === "scan" ? <Scanner onCode={(code) => void onScan(code)} onClose={() => setOverlay(null)} /> : null}

      {overlay?.type === "edit" && warehouseId ? (
        <ItemEditor
          warehouseId={warehouseId}
          item={overlay.itemId ? liveItem(overlay.itemId) : null}
          presetCode={overlay.presetCode}
          onClose={() => setOverlay(null)}
          onSaved={(result) => {
            setOverlay(null);
            publish(result, "Articolo salvato");
          }}
        />
      ) : null}

      {overlay?.type === "move" && warehouseId ? (
        <MovePad
          warehouseId={warehouseId}
          item={liveItem(overlay.itemId)}
          initialKind={overlay.kind}
          onClose={() => setOverlay({ type: "detail", itemId: overlay.itemId })}
          onSaved={(result, kind) => {
            setOverlay({ type: "detail", itemId: result.item.id });
            publish(result, kind === "prelievo" ? "Prelievo registrato" : "Carico registrato");
          }}
        />
      ) : null}

      {overlay?.type === "detail" && warehouse ? (
        <ItemDetail
          item={liveItem(overlay.itemId)}
          moves={movesQuery.data ?? []}
          onBack={() => setOverlay(null)}
          onMove={(kind) => setOverlay({ type: "move", itemId: overlay.itemId, kind })}
          onEdit={() => setOverlay({ type: "edit", itemId: overlay.itemId })}
          onDeleted={() => {
            setOverlay(null);
            setToast("Articolo eliminato");
            void refresh();
          }}
          warehouseId={warehouse.id}
        />
      ) : null}

      {overlay?.type === "log" ? (
        <LogView
          moves={movesQuery.data ?? []}
          loading={movesQuery.isLoading}
          onBack={() => setOverlay(null)}
        />
      ) : null}

      {!overlay ? (
        <>
          <header className="topbar">
            <div className="min-w-0">
              <p className="eyebrow">Stiva</p>
              <h1 className="truncate text-lg font-semibold tracking-tight">
                {warehouse ? warehouse.name : "Magazzino condiviso"}
              </h1>
            </div>
            {warehouse ? (
              <button
                type="button"
                className="icon-btn bell"
                aria-label={alerts.length ? `${alerts.length} avvisi` : "Avvisi"}
                onClick={() => setDefer(false)}
              >
                <Bell className="size-5" aria-hidden="true" />
                {alerts.length ? <span className="bell-count">{alerts.length}</span> : null}
              </button>
            ) : null}
          </header>

          {!warehouse ? (
            <HomeGate email={user?.primaryEmail ?? ""} onReady={remember} />
          ) : tab === "stock" ? (
            <section className="pad stack">
              <div className="flex gap-2">
                <div className="stat">
                  <b>{items.length}</b>
                  <span className="meta">Articoli</span>
                </div>
                <div className="stat">
                  <b>{lowCount}</b>
                  <span className="meta">Sotto soglia</span>
                </div>
              </div>
              <div className="flex gap-2">
                <label className="field min-w-0 flex-1">
                  <span className="sr-only">Cerca</span>
                  <input
                    value={query}
                    placeholder="Cerca codice o nome"
                    onChange={(event) => setQuery(event.target.value)}
                  />
                </label>
                <button type="button" className="btn btn-ghost" onClick={() => setOverlay({ type: "log", itemId: null })}>
                  Registro
                </button>
              </div>
              <div className="chips">
                <button type="button" className="chip" aria-pressed={!onlyLow} onClick={() => setOnlyLow(false)}>
                  Tutti
                </button>
                <button type="button" className="chip" aria-pressed={onlyLow} onClick={() => setOnlyLow(true)}>
                  Sotto soglia
                </button>
              </div>
              {itemsQuery.isLoading ? (
                <div className="stack">
                  <div className="skeleton" />
                  <div className="skeleton" />
                  <div className="skeleton" />
                </div>
              ) : itemsQuery.isError ? (
                <p className="note note-danger" role="alert">
                  {messageOf(itemsQuery.error)}
                </p>
              ) : filtered.length === 0 ? (
                <div className="card stack">
                  <h2 className="text-lg font-semibold">
                    {items.length === 0 ? "Nessun articolo" : "Nessun risultato"}
                  </h2>
                  <p className="lede">
                    {items.length === 0
                      ? "Aggiungi un codice con la giacenza e la soglia minima. Il QR servirà a prelevare dal telefono."
                      : "Prova un altro codice o togli il filtro."}
                  </p>
                  {items.length === 0 ? (
                    <button
                      type="button"
                      className="btn btn-primary"
                      onClick={() => setOverlay({ type: "edit", itemId: null })}
                    >
                      Nuovo articolo
                    </button>
                  ) : null}
                </div>
              ) : (
                <div className="stack">
                  {filtered.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      className="item-row"
                      onClick={() => setOverlay({ type: "detail", itemId: item.id })}
                    >
                      <span className="min-w-0">
                        <span className="flex items-center gap-2">
                          <span className="code text-sm">{item.code}</span>
                          <StatusPill item={item} />
                        </span>
                        <span className="mt-1 block truncate font-medium">{item.name}</span>
                        <span className="meta">
                          Soglia {formatQty(item.min_qty)} {item.unit}
                          {item.location ? ` · ${item.location}` : ""}
                        </span>
                      </span>
                      <span className="text-right">
                        <span className="qty text-2xl">{formatQty(item.qty)}</span>
                        <span className="meta block">{item.unit}</span>
                      </span>
                    </button>
                  ))}
                </div>
              )}
              <button
                type="button"
                className="btn btn-ghost w-full"
                onClick={() => setOverlay({ type: "edit", itemId: null })}
              >
                <Plus className="size-4" aria-hidden="true" />
                Nuovo articolo
              </button>
            </section>
          ) : (
            <TeamPanel
              warehouse={warehouse}
              members={membersQuery.data ?? []}
              autoMail={autoMail}
              perm={perm}
              onAutoMail={(value) => {
                setAutoMail(value);
                localStorage.setItem(AUTO_MAIL_KEY, value ? "1" : "0");
              }}
              onPerm={setPerm}
              onSwitch={chooseWarehouse}
              warehouses={warehouses.data ?? []}
              onLeft={() => forget(warehouse.id)}
              onToast={setToast}
            />
          )}

          {warehouse ? (
            <nav className="dock no-print" aria-label="Sezioni">
              <button type="button" aria-current={tab === "stock" ? "page" : undefined} onClick={() => setTab("stock")}>
                <Package className="size-5" aria-hidden="true" />
                Scorte
              </button>
              <button type="button" className="items-center" onClick={() => setOverlay({ type: "scan" })}>
                <span className="scan-fab grid place-items-center">
                  <ScanLine className="size-6" aria-hidden="true" />
                </span>
                Scansiona
              </button>
              <button type="button" aria-current={tab === "team" ? "page" : undefined} onClick={() => setTab("team")}>
                <Users className="size-5" aria-hidden="true" />
                Squadra
              </button>
            </nav>
          ) : null}
        </>
      ) : null}

      <Dialog.Root open={showAlert} onOpenChange={(open) => { if (!open) setDefer(true); }}>
        <Dialog.Portal>
          <Dialog.Overlay className="modal-overlay" />
          <Dialog.Content className="modal-card" aria-describedby="alert-copy">
            <div className="modal-inner stack">
              <p className="eyebrow">Avviso</p>
              <Dialog.Title className="text-2xl font-semibold tracking-tight">Soglia minima raggiunta</Dialog.Title>
              <Dialog.Description id="alert-copy" className="lede">
                La giacenza è scesa sotto il limite. L'avviso resta sullo schermo finché non lo confermi.
              </Dialog.Description>
              <ul className="stack">
                {alerts.map((alert) => (
                  <li key={alert.id} className="card">
                    <p className="code text-sm">{alert.item_code}</p>
                    <p className="font-medium">{alert.item_name}</p>
                    <p className="qty mt-2 text-xl">
                      {formatQty(alert.qty_after)} {alert.unit}
                    </p>
                    <p className="meta">Soglia {formatQty(alert.min_qty)} {alert.unit}</p>
                  </li>
                ))}
              </ul>
              {mailHref ? (
                <button type="button" className="btn btn-primary w-full" onClick={() => openMail(mailHref)}>
                  <Mail className="size-4" aria-hidden="true" />
                  Invia mail al gruppo
                </button>
              ) : (
                <p className="note">
                  Nessuna mail impostata. In Squadra aggiungi l'indirizzo: l'avviso a schermo è già attivo.
                </p>
              )}
              {mailHref ? (
                <p className="meta">
                  Si apre la posta del telefono, già compilata
                  {alerts[0]?.recipients ? ` per ${alerts[0].recipients}` : ""}.
                </p>
              ) : null}
              <button
                type="button"
                className="btn btn-ghost w-full"
                disabled={ack.isPending || !warehouseId}
                onClick={() => ack.mutate()}
              >
                <Check className="size-4" aria-hidden="true" />
                {ack.isPending ? "Salvo…" : "Ho visto"}
              </button>
            </div>
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>

      {toast ? <div className="toast">{toast}</div> : null}
    </div>
  );
}

function HomeGate({
  email,
  onReady,
}: {
  email: string;
  onReady: (warehouse: Warehouse) => void;
}) {
  const [mode, setMode] = useState<"choose" | "create" | "join">("choose");
  const [name, setName] = useState("");
  const [notifyEmail, setNotifyEmail] = useState(email);
  const [code, setCode] = useState("");
  const [error, setError] = useState<string | null>(null);

  const create = useMutation({
    mutationFn: () => createWarehouse({ data: { name, notifyEmail } }),
    onSuccess: (warehouse) => onReady(warehouse),
    onError: (caught) => setError(messageOf(caught)),
  });
  const join = useMutation({
    mutationFn: () => joinWarehouse({ data: { code } }),
    onSuccess: (warehouse) => onReady(warehouse),
    onError: (caught) => setError(messageOf(caught)),
  });

  return (
    <section className="pad stack">
      <p className="lede">
        Un codice per gli amici, le quantità sempre aggiornate. Chi preleva inquadra il QR e, sotto la soglia, il
        gruppo riceve l'avviso.
      </p>
      {mode === "choose" ? (
        <>
          <button type="button" className="btn btn-primary w-full" onClick={() => setMode("create")}>
            Crea un magazzino
          </button>
          <button type="button" className="btn btn-ghost w-full" onClick={() => setMode("join")}>
            Entra con un codice
          </button>
        </>
      ) : null}
      {mode === "create" ? (
        <form
          className="card stack"
          onSubmit={(event) => {
            event.preventDefault();
            setError(null);
            create.mutate();
          }}
        >
          <h2 className="text-lg font-semibold">Nuovo magazzino</h2>
          <label className="field">
            <span>Nome</span>
            <input id="wh-name" required value={name} placeholder="Officina, furgone, cantiere" onChange={(event) => setName(event.target.value)} />
          </label>
          <label className="field">
            <span>Mail per gli avvisi</span>
            <input
              type="email"
              value={notifyEmail}
              placeholder="Anche una casella condivisa"
              onChange={(event) => setNotifyEmail(event.target.value)}
            />
          </label>
          {error ? <p className="note note-danger" role="alert">{error}</p> : null}
          <button className="btn btn-primary" type="submit" disabled={create.isPending}>
            {create.isPending ? "Creo…" : "Crea e condividi"}
          </button>
          <button type="button" className="btn btn-ghost" onClick={() => setMode("choose")}>
            Indietro
          </button>
        </form>
      ) : null}
      {mode === "join" ? (
        <form
          className="card stack"
          onSubmit={(event) => {
            event.preventDefault();
            setError(null);
            join.mutate();
          }}
        >
          <h2 className="text-lg font-semibold">Codice magazzino</h2>
          <label className="field">
            <span>Codice</span>
            <input
              id="join-code"
              required
              className="code"
              autoCapitalize="characters"
              value={code}
              placeholder="ABC-123"
              onChange={(event) => setCode(event.target.value)}
            />
          </label>
          {error ? <p className="note note-danger" role="alert">{error}</p> : null}
          <button className="btn btn-primary" type="submit" disabled={join.isPending}>
            {join.isPending ? "Entro…" : "Entra"}
          </button>
          <button type="button" className="btn btn-ghost" onClick={() => setMode("choose")}>
            Indietro
          </button>
        </form>
      ) : null}
    </section>
  );
}

function ItemEditor({
  warehouseId,
  item,
  presetCode,
  onClose,
  onSaved,
}: {
  warehouseId: string;
  item: Item | null;
  presetCode?: string;
  onClose: () => void;
  onSaved: (result: StockChange) => void;
}) {
  const [code, setCode] = useState(item?.code ?? presetCode ?? "");
  const [name, setName] = useState(item?.name ?? "");
  const [unit, setUnit] = useState(item?.unit ?? "pz");
  const [qty, setQty] = useState(item ? formatQtyInput(item.qty) : "");
  const [minQty, setMinQty] = useState(item ? formatQtyInput(item.min_qty) : "");
  const [location, setLocation] = useState(item?.location ?? "");
  const [error, setError] = useState<string | null>(null);
  const units = UNITS.includes(unit as (typeof UNITS)[number]) ? UNITS : [unit, ...UNITS];

  const save = useMutation({
    mutationFn: () => {
      const parsedQty = parseQty(qty);
      const parsedMin = parseQty(minQty || "0");
      if (parsedQty === null || parsedMin === null) throw new Error("Controlla giacenza e soglia.");
      return saveItem({
        data: {
          warehouseId,
          id: item?.id ?? null,
          code,
          name,
          unit,
          qty: parsedQty,
          minQty: parsedMin,
          location,
        },
      });
    },
    onSuccess: onSaved,
    onError: (caught) => setError(messageOf(caught)),
  });

  return (
    <form
      className="stack"
      onSubmit={(event) => {
        event.preventDefault();
        setError(null);
        save.mutate();
      }}
    >
      <div className="sheet-top">
        <button type="button" className="icon-btn" onClick={onClose} aria-label="Indietro">
          <ChevronLeft className="size-5" />
        </button>
        <h1 className="min-w-0 flex-1 text-lg font-semibold">{item ? "Modifica articolo" : "Nuovo articolo"}</h1>
      </div>
      <div className="pad stack">
        <label className="field">
          <span>Codice</span>
          <input
            id="item-code"
            required
            className="code"
            autoCapitalize="characters"
            value={code}
            placeholder="Quello sul QR o sul codice a barre"
            onChange={(event) => setCode(event.target.value)}
          />
        </label>
        <label className="field">
          <span>Nome</span>
          <input id="item-name" required value={name} onChange={(event) => setName(event.target.value)} />
        </label>
        <div className="grid grid-cols-2 gap-3">
          <label className="field">
            <span>Giacenza</span>
            <input id="item-qty" inputMode="decimal" required value={qty} onChange={(event) => setQty(event.target.value)} />
          </label>
          <label className="field">
            <span>Soglia minima</span>
            <input id="item-min" inputMode="decimal" required value={minQty} placeholder="0" onChange={(event) => setMinQty(event.target.value)} />
          </label>
        </div>
        <label className="field">
          <span>Unità</span>
          <select value={unit} onChange={(event) => setUnit(event.target.value)}>
            {units.map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>
        </label>
        <label className="field">
          <span>Ubicazione</span>
          <input value={location} placeholder="Scaffale, furgone, cantiere" onChange={(event) => setLocation(event.target.value)} />
        </label>
        <p className="meta">Sotto la soglia, Stiva avvisa a schermo e prepara la mail per la squadra.</p>
        {error ? <p className="note note-danger" role="alert">{error}</p> : null}
        <button className="btn btn-primary w-full" type="submit" disabled={save.isPending}>
          {save.isPending ? "Salvo…" : "Salva articolo"}
        </button>
      </div>
    </form>
  );
}

function MovePad({
  warehouseId,
  item,
  initialKind,
  onClose,
  onSaved,
}: {
  warehouseId: string;
  item: Item | null;
  initialKind: Kind;
  onClose: () => void;
  onSaved: (result: StockChange, kind: Kind) => void;
}) {
  const [kind, setKind] = useState<Kind>(initialKind);
  const [qty, setQty] = useState("1");
  const [note, setNote] = useState("");
  const [error, setError] = useState<string | null>(null);
  const parsed = parseQty(qty);
  const next = item && parsed !== null ? (kind === "prelievo" ? item.qty - parsed : item.qty + parsed) : null;
  const blocked = kind === "prelievo" && item && parsed !== null && parsed > item.qty;

  const move = useMutation({
    mutationFn: () => {
      if (!item) throw new Error("Articolo non trovato.");
      const amount = parseQty(qty);
      if (amount === null || amount <= 0) throw new Error("Inserisci una quantità maggiore di zero.");
      return recordMove({
        data: { warehouseId, itemId: item.id, kind, qty: amount, note },
      });
    },
    onSuccess: (result) => onSaved(result, kind),
    onError: (caught) => setError(messageOf(caught)),
  });

  if (!item) {
    return (
      <section className="pad stack">
        <button type="button" className="btn btn-ghost" onClick={onClose}>
          Indietro
        </button>
        <p className="note">Articolo non trovato.</p>
      </section>
    );
  }

  return (
    <form
      className="stack"
      onSubmit={(event) => {
        event.preventDefault();
        setError(null);
        move.mutate();
      }}
    >
      <div className="sheet-top">
        <button type="button" className="icon-btn" onClick={onClose} aria-label="Indietro">
          <ChevronLeft className="size-5" />
        </button>
        <div className="min-w-0 flex-1">
          <p className="code text-sm">{item.code}</p>
          <h1 className="truncate text-lg font-semibold">{item.name}</h1>
        </div>
      </div>
      <div className="pad stack">
        <p className="meta">
          Giacenza {formatQty(item.qty)} {item.unit} · soglia {formatQty(item.min_qty)}
        </p>
        <div className="chips">
          <button type="button" className="chip" aria-pressed={kind === "prelievo"} onClick={() => setKind("prelievo")}>
            Prelievo
          </button>
          <button type="button" className="chip" aria-pressed={kind === "carico"} onClick={() => setKind("carico")}>
            Carico
          </button>
        </div>
        <label className="field">
          <span>Quantità {kind === "prelievo" ? "prelevata" : "caricata"}</span>
          <input
            id="move-qty"
            className="qty text-3xl"
            inputMode="decimal"
            value={qty}
            onChange={(event) => setQty(event.target.value)}
          />
        </label>
        <div className="flex gap-2">
          <button type="button" className="icon-btn" aria-label="Diminuisci" onClick={() => setQty(String(Math.max(0, (parsed ?? 0) - 1)))}>
            <Minus className="size-4" />
          </button>
          {["1", "5", "10"].map((preset) => (
            <button key={preset} type="button" className="chip" onClick={() => setQty(preset)}>
              {preset}
            </button>
          ))}
          <button type="button" className="icon-btn" aria-label="Aumenta" onClick={() => setQty(String((parsed ?? 0) + 1))}>
            <Plus className="size-4" />
          </button>
        </div>
        {next !== null ? (
          <p className={next <= item.min_qty ? "note note-warn" : "note"}>
            Dopo il movimento: {formatQty(Math.max(0, next))} {item.unit}
            {next <= item.min_qty ? " · scatta l'avviso di soglia" : ""}
          </p>
        ) : null}
        {blocked ? <p className="note note-danger">Quantità maggiore della giacenza.</p> : null}
        <label className="field">
          <span>Nota</span>
          <input value={note} placeholder="Commessa, cliente, motivo" onChange={(event) => setNote(event.target.value)} />
        </label>
        {error ? <p className="note note-danger" role="alert">{error}</p> : null}
        <button className="btn btn-primary w-full" type="submit" disabled={move.isPending || Boolean(blocked) || !parsed}>
          {move.isPending ? "Registro…" : kind === "prelievo" ? "Registra prelievo" : "Registra carico"}
        </button>
      </div>
    </form>
  );
}

function ItemDetail({
  warehouseId,
  item,
  moves,
  onBack,
  onMove,
  onEdit,
  onDeleted,
}: {
  warehouseId: string;
  item: Item | null;
  moves: Movement[];
  onBack: () => void;
  onMove: (kind: Kind) => void;
  onEdit: () => void;
  onDeleted: () => void;
}) {
  const [confirm, setConfirm] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const remove = useMutation({
    mutationFn: () => deleteItem({ data: { warehouseId, itemId: item!.id } }),
    onSuccess: onDeleted,
    onError: (caught) => setError(messageOf(caught)),
  });

  if (!item) {
    return (
      <section className="pad">
        <button type="button" className="btn btn-ghost" onClick={onBack}>
          Indietro
        </button>
      </section>
    );
  }

  return (
    <article>
      <div className="sheet-top no-print">
        <button type="button" className="icon-btn" onClick={onBack} aria-label="Indietro">
          <ChevronLeft className="size-5" />
        </button>
        <h1 className="min-w-0 flex-1 truncate text-lg font-semibold">{item.name}</h1>
        <button type="button" className="icon-btn" onClick={onEdit} aria-label="Modifica">
          <Pencil className="size-4" />
        </button>
      </div>
      <div className="pad stack items-center text-center">
        <QrImage code={item.code} />
        <p className="code text-2xl">{item.code}</p>
        <p className="qty text-4xl">
          {formatQty(item.qty)} <span className="text-lg text-muted">{item.unit}</span>
        </p>
        <StatusPill item={item} />
        <p className="meta">Soglia minima {formatQty(item.min_qty)} {item.unit}</p>
        {item.location ? (
          <p className="meta inline-flex items-center gap-1">
            <MapPin className="size-4" aria-hidden="true" />
            {item.location}
          </p>
        ) : null}
        <p className="meta max-w-sm">
          Stampa l'etichetta e applicala sull'articolo. In Stiva, Scansiona legge il QR e apre il prelievo.
        </p>
      </div>
      <div className="pad stack no-print">
        <button type="button" className="btn btn-primary w-full" onClick={() => onMove("prelievo")}>
          Registra prelievo
        </button>
        <button type="button" className="btn btn-ghost w-full" onClick={() => onMove("carico")}>
          Registra carico
        </button>
        <button type="button" className="btn btn-ghost w-full" onClick={() => window.print()}>
          Stampa etichetta
        </button>
        {confirm ? (
          <button type="button" className="btn btn-danger w-full" disabled={remove.isPending} onClick={() => remove.mutate()}>
            {remove.isPending ? "Elimino…" : "Conferma eliminazione"}
          </button>
        ) : (
          <button type="button" className="btn btn-ghost w-full" onClick={() => setConfirm(true)}>
            <Trash2 className="size-4" aria-hidden="true" />
            Elimina articolo
          </button>
        )}
        {error ? <p className="note note-danger">{error}</p> : null}
        <h2 className="pt-2 text-left text-base font-semibold">Ultimi movimenti</h2>
        <MoveList moves={moves} />
      </div>
    </article>
  );
}

function LogView({
  moves,
  loading,
  onBack,
}: {
  moves: Movement[];
  loading: boolean;
  onBack: () => void;
}) {
  return (
    <section>
      <div className="sheet-top">
        <button type="button" className="icon-btn" onClick={onBack} aria-label="Indietro">
          <ChevronLeft className="size-5" />
        </button>
        <h1 className="text-lg font-semibold">Registro</h1>
      </div>
      <div className="pad">
        {loading ? <div className="skeleton" /> : <MoveList moves={moves} />}
      </div>
    </section>
  );
}

function MoveList({ moves }: { moves: Movement[] }) {
  if (!moves.length) return <p className="meta">Nessun movimento.</p>;
  return (
    <ul className="stack text-left">
      {moves.map((move) => (
        <li key={move.id} className="card">
          <p className="flex items-baseline justify-between gap-3">
            <span className="font-medium">
              {move.kind === "prelievo" ? "Prelievo" : move.kind === "carico" ? "Carico" : "Rettifica"}
              {" · "}
              {move.item_code}
            </span>
            <span className="code text-sm">
              {move.kind === "carico" ? "+" : move.kind === "prelievo" ? "−" : ""}
              {formatQty(move.qty)}
            </span>
          </p>
          <p className="meta">
            {move.actor_name} · {formatQty(move.qty_before)} → {formatQty(move.qty_after)} · {formatWhen(move.created_at)}
          </p>
          {move.note ? <p className="mt-1 text-sm">{move.note}</p> : null}
        </li>
      ))}
    </ul>
  );
}

function TeamPanel({
  warehouse,
  members,
  warehouses,
  autoMail,
  perm,
  onAutoMail,
  onPerm,
  onSwitch,
  onLeft,
  onToast,
}: {
  warehouse: { id: string; name: string; join_code: string; notify_email: string; role: string };
  members: Member[];
  warehouses: Array<{ id: string; name: string }>;
  autoMail: boolean;
  perm: NotificationPermission | "unsupported";
  onAutoMail: (value: boolean) => void;
  onPerm: (value: NotificationPermission | "unsupported") => void;
  onSwitch: (id: string) => void;
  onLeft: () => void;
  onToast: (text: string) => void;
}) {
  const [mail, setMail] = useState(warehouse.notify_email);
  const [error, setError] = useState<string | null>(null);
  const [danger, setDanger] = useState<"leave" | "delete" | null>(null);
  const code = formatJoin(warehouse.join_code);
  const shareText = `Entra nel magazzino ${warehouse.name} su Stiva. Codice: ${code}`;

  const saveMail = useMutation({
    mutationFn: () => updateNotifyEmail({ data: { warehouseId: warehouse.id, notifyEmail: mail } }),
    onSuccess: () => onToast("Mail di avviso aggiornata"),
    onError: (caught) => setError(messageOf(caught)),
  });
  const leave = useMutation({
    mutationFn: () => leaveWarehouse({ data: { warehouseId: warehouse.id } }),
    onSuccess: onLeft,
    onError: (caught) => setError(messageOf(caught)),
  });
  const remove = useMutation({
    mutationFn: () => deleteWarehouse({ data: { warehouseId: warehouse.id } }),
    onSuccess: onLeft,
    onError: (caught) => setError(messageOf(caught)),
  });

  async function copyCode() {
    try {
      await navigator.clipboard.writeText(code);
      onToast("Codice copiato");
    } catch {
      onToast(code);
    }
  }

  async function share() {
    try {
      if (navigator.share) await navigator.share({ title: "Stiva", text: shareText });
      else await copyCode();
    } catch {
      /* share sheet closed */
    }
  }

  return (
    <section className="pad stack">
      <div className="card stack">
        <p className="eyebrow">Codice per gli amici</p>
        <p className="code text-4xl">{code}</p>
        <p className="meta">Chi ha un account Stiva può entrare e vedere le stesse quantità.</p>
        <div className="flex gap-2">
          <button id="copy-code" type="button" className="btn btn-primary flex-1" onClick={() => void copyCode()}>
            <Copy className="size-4" aria-hidden="true" />
            Copia
          </button>
          <button type="button" className="btn btn-ghost flex-1" onClick={() => void share()}>
            <Share2 className="size-4" aria-hidden="true" />
            Condividi
          </button>
        </div>
      </div>

      <form
        className="card stack"
        onSubmit={(event) => {
          event.preventDefault();
          setError(null);
          saveMail.mutate();
        }}
      >
        <h2 className="font-semibold">Mail di avviso</h2>
        <p className="meta">
          Oltre alle mail degli account in squadra. Quando scatta la soglia si apre il messaggio già scritto.
        </p>
        <label className="field">
          <span>Indirizzo</span>
          <input type="email" value={mail} onChange={(event) => setMail(event.target.value)} />
        </label>
        <button className="btn btn-ghost" type="submit" disabled={saveMail.isPending}>
          {saveMail.isPending ? "Salvo…" : "Salva mail"}
        </button>
        <button
          type="button"
          className="chip w-fit"
          aria-pressed={autoMail}
          onClick={() => onAutoMail(!autoMail)}
        >
          {autoMail ? "Mail pronta in automatico" : "Mail solo su richiesta"}
        </button>
      </form>

      <div className="card stack">
        <h2 className="font-semibold">Notifica sul telefono</h2>
        <p className="meta">
          Aggiungi Stiva alla schermata Home. Con il permesso, l'avviso di soglia compare anche fuori dalla pagina.
        </p>
        <button
          type="button"
          className="btn btn-ghost"
          onClick={() => {
            void requestScreenNotifications().then((value) => {
              onPerm(value);
              onToast(value === "granted" ? "Notifiche attive" : "Permesso non concesso");
            });
          }}
        >
          <Bell className="size-4" aria-hidden="true" />
          {perm === "granted" ? "Notifiche attive" : perm === "unsupported" ? "Non disponibili qui" : "Attiva notifiche"}
        </button>
      </div>

      <div className="card stack">
        <h2 className="font-semibold">Squadra</h2>
        <ul className="stack">
          {members.map((member) => (
            <li key={member.user_id} className="flex items-baseline justify-between gap-3">
              <span>
                <span className="block font-medium">{member.display_name || "Operatore"}</span>
                <span className="meta">{member.email || "Senza mail"}</span>
              </span>
              <span className="meta">{member.role === "owner" ? "Responsabile" : "In squadra"}</span>
            </li>
          ))}
        </ul>
      </div>

      {warehouses.length > 1 ? (
        <div className="card stack">
          <h2 className="font-semibold">Altri magazzini</h2>
          {warehouses
            .filter((row) => row.id !== warehouse.id)
            .map((row) => (
              <button key={row.id} type="button" className="btn btn-ghost w-full" onClick={() => onSwitch(row.id)}>
                {row.name}
              </button>
            ))}
        </div>
      ) : null}

      <SignOutRow />
      {error ? <p className="note note-danger" role="alert">{error}</p> : null}
      {warehouse.role === "owner" ? (
        danger === "delete" ? (
          <button type="button" className="btn btn-danger w-full" disabled={remove.isPending} onClick={() => remove.mutate()}>
            {remove.isPending ? "Elimino…" : "Conferma: elimina magazzino"}
          </button>
        ) : (
          <button type="button" className="btn btn-ghost w-full" onClick={() => setDanger("delete")}>
            Elimina magazzino
          </button>
        )
      ) : danger === "leave" ? (
        <button type="button" className="btn btn-danger w-full" disabled={leave.isPending} onClick={() => leave.mutate()}>
          {leave.isPending ? "Esco…" : "Conferma: esci dalla squadra"}
        </button>
      ) : (
        <button type="button" className="btn btn-ghost w-full" onClick={() => setDanger("leave")}>
          Esci dalla squadra
        </button>
      )}
    </section>
  );
}

function SignOutRow() {
  const user = useCurrentUser();
  const [pending, setPending] = useState(false);
  const gate = useSyncExternalStore(() => () => {}, hasGateSessionMarker, () => false);
  if (!user) return null;
  return (
    <div className="card stack">
      <p className="font-medium">{user.displayName ?? "Account"}</p>
      <p className="meta">{user.primaryEmail}</p>
      {gate ? null : (
        <button
          type="button"
          className="btn btn-ghost"
          disabled={pending}
          onClick={() => {
            setPending(true);
            void signOut().catch(() => setPending(false));
          }}
        >
          {pending ? "Uscita…" : "Esci dall'account"}
        </button>
      )}
    </div>
  );
}
