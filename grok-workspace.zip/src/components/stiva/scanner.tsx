import { useEffect, useRef, useState } from "react";
import { Keyboard, X } from "lucide-react";
import { extractCode } from "@/lib/stiva/format";

type Detector = {
  detect: (source: CanvasImageSource) => Promise<Array<{ rawValue?: string }>>;
};

export function Scanner({
  onCode,
  onClose,
}: {
  onCode: (code: string) => void;
  onClose: () => void;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [manual, setManual] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(true);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    let cancel = false;
    let stream: MediaStream | null = null;
    let frame = 0;
    let controls: { stop: () => void } | null = null;

    const stopTracks = () => {
      stream?.getTracks().forEach((track) => track.stop());
      stream = null;
    };

    const finish = (raw: string) => {
      const code = extractCode(raw);
      if (!code || cancel) return;
      cancel = true;
      cancelAnimationFrame(frame);
      controls?.stop();
      stopTracks();
      onCode(code);
    };

    const fail = (caught: unknown) => {
      if (cancel) return;
      const name = caught instanceof DOMException ? caught.name : "";
      if (name === "NotAllowedError") {
        setError("Permesso fotocamera negato. Inserisci il codice a mano.");
      } else {
        setError("Fotocamera non disponibile. Inserisci il codice a mano.");
      }
      setBusy(false);
    };

    void (async () => {
      const DetectorCtor = (
        window as unknown as {
          BarcodeDetector?: new (opts?: { formats?: string[] }) => Detector;
        }
      ).BarcodeDetector;

      if (DetectorCtor && navigator.mediaDevices?.getUserMedia) {
        try {
          stream = await navigator.mediaDevices.getUserMedia({
            audio: false,
            video: { facingMode: { ideal: "environment" } },
          });
          if (cancel) {
            stopTracks();
            return;
          }
          video.srcObject = stream;
          await video.play();
          setBusy(false);
          const detector = new DetectorCtor({
            formats: ["qr_code", "ean_13", "ean_8", "code_128", "code_39", "upc_a", "upc_e", "itf"],
          });
          const tick = async () => {
            if (cancel) return;
            try {
              const found = await detector.detect(video);
              const raw = found.find((row) => row.rawValue)?.rawValue;
              if (raw) {
                finish(raw);
                return;
              }
            } catch {
              /* frame not ready */
            }
            frame = requestAnimationFrame(() => void tick());
          };
          frame = requestAnimationFrame(() => void tick());
          return;
        } catch (caught) {
          stopTracks();
          fail(caught);
          return;
        }
      }

      try {
        const { BrowserMultiFormatReader } = await import("@zxing/browser");
        if (cancel) return;
        const reader = new BrowserMultiFormatReader();
        controls = await reader.decodeFromVideoDevice(undefined, video, (result) => {
          if (result) finish(result.getText());
        });
        if (cancel) controls.stop();
        else setBusy(false);
      } catch (caught) {
        fail(caught);
      }
    })();

    return () => {
      cancel = true;
      cancelAnimationFrame(frame);
      controls?.stop();
      stopTracks();
    };
  }, [onCode]);

  return (
    <section className="fixed inset-0 z-40 flex flex-col bg-ink text-accent-fg">
      <div className="sheet-top border-transparent bg-ink text-accent-fg">
        <div>
        <p className="eyebrow finder-kicker">Lettura</p>
          <h1 className="wordmark">Inquadra il codice</h1>
        </div>
        <button type="button" className="icon-btn finder-close" onClick={onClose}>
          <X className="size-5" aria-hidden="true" />
          <span className="sr-only">Chiudi</span>
        </button>
      </div>
      <div className="finder">
        <video ref={videoRef} muted playsInline autoPlay />
        <div className="finder-frame" />
        {busy && !error ? (
          <p className="absolute inset-x-0 bottom-4 text-center text-sm">Avvio fotocamera…</p>
        ) : null}
      </div>
      <form
        className="stack bg-bg p-4 text-ink"
        onSubmit={(event) => {
          event.preventDefault();
          const code = extractCode(manual);
          if (!code) return;
          onCode(code);
        }}
      >
        {error ? <p className="note-danger note">{error}</p> : null}
        <label className="field">
          <span className="inline-flex items-center gap-1">
            <Keyboard className="size-4" aria-hidden="true" />
            Oppure scrivi il codice
          </span>
          <input
            id="scan-code"
            value={manual}
            autoCapitalize="characters"
            autoCorrect="off"
            placeholder="Es. VITE-M8"
            onChange={(event) => setManual(event.target.value)}
          />
        </label>
        <button type="submit" className="btn btn-primary w-full">
          Seleziona articolo
        </button>
      </form>
    </section>
  );
}
