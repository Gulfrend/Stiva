import { useState, type FormEvent } from "react";
import { GROK_PROVIDERS, authClient, signIn } from "@/lib/auth/client";

function mapAuthError(message: string | undefined) {
  const text = (message ?? "").toLowerCase();
  if (text.includes("already") || text.includes("exist")) return "Esiste già un account con questa mail.";
  if (text.includes("short") || text.includes("least")) return "La password deve avere almeno 8 caratteri.";
  if (text.includes("invalid") || text.includes("credential") || text.includes("incorrect")) {
    return "Mail o password non corrette.";
  }
  return message || "Accesso non riuscito. Riprova.";
}

export function BootScreen({ label = "Stiva" }: { label?: string }) {
  return (
    <main className="grid min-h-screen place-items-center bg-bg px-6">
      <div className="text-center">
        <p className="eyebrow">Magazzino</p>
        <h1 className="wordmark text-3xl">{label}</h1>
      </div>
    </main>
  );
}

export function LoginPanel({ next = "/" }: { next?: string }) {
  const [mode, setMode] = useState<"in" | "up">("in");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setError(null);
    setPending(true);
    try {
      if (mode === "up") {
        const result = await authClient.signUp.email({ email, password, name: name.trim() });
        if (result.error) throw new Error(result.error.message);
      } else {
        const result = await authClient.signIn.email({ email, password });
        if (result.error) throw new Error(result.error.message);
      }
      window.location.assign(next);
    } catch (caught) {
      setError(mapAuthError(caught instanceof Error ? caught.message : undefined));
      setPending(false);
    }
  }

  return (
    <main className="mx-auto flex min-h-screen w-full max-w-xl flex-col justify-center bg-bg px-5 py-10">
      <p className="eyebrow">Magazzino condiviso</p>
      <h1 className="mt-2 text-4xl font-semibold tracking-tight">Stiva</h1>
      <p className="lede mt-3 max-w-md">
        Inserisci i codici, tieni le quantità e preleva leggendo il QR. Sotto la soglia parte l'avviso a
        schermo e la mail per il gruppo.
      </p>

      <form className="card stack mt-8" onSubmit={(event) => void submit(event)}>
        <h2 className="text-lg font-semibold">{mode === "up" ? "Crea l'account" : "Entra"}</h2>
        {mode === "up" ? (
          <label className="field">
            <span>Nome</span>
            <input
              id="login-name"
              required
              autoComplete="name"
              value={name}
              placeholder="Come ti vedono in squadra"
              onChange={(event) => setName(event.target.value)}
            />
          </label>
        ) : null}
        <label className="field">
          <span>Mail</span>
          <input
            id="login-email"
            type="email"
            required
            autoComplete="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
          />
        </label>
        <label className="field">
          <span>Password</span>
          <input
            id="login-password"
            type="password"
            required
            minLength={8}
            autoComplete={mode === "up" ? "new-password" : "current-password"}
            value={password}
            onChange={(event) => setPassword(event.target.value)}
          />
        </label>
        {error ? (
          <p className="note note-danger" role="alert">
            {error}
          </p>
        ) : null}
        <button className="btn btn-primary w-full" type="submit" disabled={pending}>
          {pending ? "Attendi…" : mode === "up" ? "Crea account" : "Entra"}
        </button>
        <button
          type="button"
          className="text-sm font-medium text-muted"
          onClick={() => {
            setMode(mode === "up" ? "in" : "up");
            setError(null);
          }}
        >
          {mode === "up" ? "Hai già un account? Entra" : "Nuovo qui? Crea un account"}
        </button>
      </form>

      <div className="stack mt-4">
        {GROK_PROVIDERS.map((provider) => (
          <button
            key={provider.providerId}
            type="button"
            className="btn btn-ghost w-full"
            onClick={() => {
              setError(null);
              void signIn(provider.providerId, { callbackURL: next }).catch((caught) => {
                setError(caught instanceof Error ? caught.message : "Accesso non riuscito.");
              });
            }}
          >
            Continua con {provider.label}
          </button>
        ))}
      </div>
    </main>
  );
}
