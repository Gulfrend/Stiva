import { useEffect, useRef, useState } from "react";
import { createFileRoute, Navigate } from "@tanstack/react-router";
import { BootScreen } from "@/components/stiva/login-panel";
import { joinWarehouse } from "@/lib/stiva/api";
import { WAREHOUSE_KEY } from "@/lib/stiva/format";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/join/$code")({ component: JoinPage });

function JoinPage() {
  const { code } = Route.useParams();
  const { user, isPending } = useCurrentUserState();
  const started = useRef(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isPending || !user || started.current) return;
    started.current = true;
    void joinWarehouse({ data: { code } })
      .then((warehouse) => {
        localStorage.setItem(WAREHOUSE_KEY, warehouse.id);
        window.location.assign("/");
      })
      .catch((caught) => {
        started.current = false;
        setError(caught instanceof Error ? caught.message : "Codice non valido.");
      });
  }, [code, isPending, user]);

  if (isPending || (user && !error)) return <BootScreen label="Entro nel magazzino…" />;
  if (!user) return <Navigate to="/login" search={{ next: `/join/${code}` }} />;

  return (
    <main className="mx-auto flex min-h-screen w-full max-w-xl flex-col justify-center gap-4 px-5">
      <p className="eyebrow">Codice</p>
      <h1 className="text-3xl font-semibold tracking-tight">Non riesco a entrare</h1>
      <p className="note note-danger" role="alert">
        {error}
      </p>
      <a className="btn btn-primary" href="/">
        Torna a Stiva
      </a>
    </main>
  );
}
