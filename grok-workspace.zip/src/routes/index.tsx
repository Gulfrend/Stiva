import { createFileRoute } from "@tanstack/react-router";
import { StivaApp } from "@/components/stiva/app";
import { BootScreen, LoginPanel } from "@/components/stiva/login-panel";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) return <BootScreen />;
  if (!user) return <LoginPanel />;
  return <StivaApp />;
}
