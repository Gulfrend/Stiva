import { useEffect } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { BootScreen, LoginPanel } from "@/components/stiva/login-panel";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

type LoginSearch = { next: string };

export const Route = createFileRoute("/login")({
  validateSearch: (search: Record<string, unknown>): LoginSearch => {
    const next = typeof search.next === "string" ? search.next : "/";
    const safe = next.startsWith("/") && !next.startsWith("//") && !next.startsWith("/\\") ? next : "/";
    return { next: safe };
  },
  component: LoginPage,
});

function LoginPage() {
  const { next } = Route.useSearch();
  const { user, isPending } = useCurrentUserState();

  useEffect(() => {
    if (!isPending && user) window.location.replace(next);
  }, [isPending, next, user]);

  if (isPending || user) return <BootScreen />;
  return <LoginPanel next={next} />;
}
