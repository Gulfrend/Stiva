import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql, type Sql } from "@/lib/db";
import {
  buildMailto,
  formatQty,
  iso,
  normalizeItemCode,
  normalizeJoin,
  num,
  round3,
  type MailLine,
} from "@/lib/stiva/format";

export type Item = {
  id: string;
  warehouse_id: string;
  code: string;
  name: string;
  unit: string;
  qty: number;
  min_qty: number;
  location: string;
  updated_at: string;
};

export type Warehouse = {
  id: string;
  name: string;
  join_code: string;
  notify_email: string;
  role: string;
  created_at: string;
};

export type Member = {
  user_id: string;
  email: string;
  display_name: string;
  role: string;
};

export type Movement = {
  id: string;
  item_id: string;
  item_code: string;
  item_name: string;
  actor_name: string;
  kind: string;
  qty: number;
  qty_before: number;
  qty_after: number;
  note: string;
  created_at: string;
};

export type StockAlert = {
  id: string;
  item_id: string;
  item_code: string;
  item_name: string;
  unit: string;
  qty_after: number;
  min_qty: number;
  message: string;
  recipients: string;
  created_at: string;
};

export type StockChange = {
  item: Item;
  threshold_hit: boolean;
  alert: StockAlert | null;
  mailto: string | null;
};

type ItemRow = {
  id: string;
  warehouse_id: string;
  code: string;
  name: string;
  unit: string;
  qty: number | string;
  min_qty: number | string;
  location: string | null;
  updated_at: string | Date;
};

function parse<S extends z.ZodType>(schema: S) {
  return (input: unknown): z.infer<S> => {
    const result = schema.safeParse(input);
    if (!result.success) {
      throw new Error(result.error.issues[0]?.message ?? "Dati non validi.");
    }
    return result.data;
  };
}

function isUnique(error: unknown) {
  if (typeof error === "object" && error !== null && "code" in error && error.code === "23505") return true;
  const msg = error instanceof Error ? error.message : String(error);
  return /unique|duplicate/i.test(msg);
}

function mapItem(row: ItemRow): Item {
  return {
    id: row.id,
    warehouse_id: row.warehouse_id,
    code: row.code,
    name: row.name,
    unit: row.unit,
    qty: num(row.qty),
    min_qty: num(row.min_qty),
    location: row.location ?? "",
    updated_at: iso(row.updated_at),
  };
}

async function actor(sql: Sql, userId: string) {
  const rows = await sql<{ name: string | null; email: string | null }>`
    select "name" as name, "email" as email from "user" where "id" = ${userId}
  `;
  const name = rows[0]?.name?.trim() || "Operatore";
  const email = rows[0]?.email?.trim().toLowerCase() || "";
  await sql`
    update warehouse_members
    set display_name = ${name}, email = ${email}
    where user_id = ${userId}
  `;
  return { name, email };
}

async function requireMember(sql: Sql, warehouseId: string, userId: string) {
  const rows = await sql<{ role: string }>`
    select role from warehouse_members
    where warehouse_id = ${warehouseId} and user_id = ${userId}
  `;
  if (!rows[0]) throw new Error("Non hai accesso a questo magazzino.");
  return rows[0].role;
}

async function loadItem(sql: Sql, warehouseId: string, id: string) {
  const rows = await sql<ItemRow>`
    select id, warehouse_id, code, name, unit, qty, min_qty, location, updated_at
    from items
    where id = ${id} and warehouse_id = ${warehouseId}
  `;
  return rows[0] ? mapItem(rows[0]) : null;
}

async function raiseAlert(
  sql: Sql,
  args: { warehouseId: string; item: Item; qtyBefore: number; minBefore: number },
): Promise<Pick<StockChange, "threshold_hit" | "alert" | "mailto">> {
  const wasAbove = args.qtyBefore > args.minBefore;
  const nowBelow = args.item.qty <= args.item.min_qty;
  if (!wasAbove || !nowBelow) {
    return { threshold_hit: false, alert: null, mailto: null };
  }

  const members = await sql<{ email: string; notify_email: string }>`
    select m.email, w.notify_email
    from warehouse_members m
    join warehouses w on w.id = m.warehouse_id
    where m.warehouse_id = ${args.warehouseId}
  `;
  const emails = new Set<string>();
  for (const row of members) {
    if (row.email?.includes("@")) emails.add(row.email.trim().toLowerCase());
    if (row.notify_email?.includes("@")) emails.add(row.notify_email.trim().toLowerCase());
  }
  const recipients = [...emails];
  const message = `${args.item.name} (${args.item.code}) è a ${formatQty(args.item.qty)} ${args.item.unit}, sotto la soglia di ${formatQty(args.item.min_qty)} ${args.item.unit}.`;
  const id = crypto.randomUUID();
  await sql`
    insert into alerts (
      id, warehouse_id, item_id, item_code, item_name, unit,
      qty_after, min_qty, message, recipients
    ) values (
      ${id},
      ${args.warehouseId},
      ${args.item.id},
      ${args.item.code},
      ${args.item.name},
      ${args.item.unit},
      ${args.item.qty},
      ${args.item.min_qty},
      ${message},
      ${recipients.join(", ")}
    )
  `;
  await sql`
    insert into alert_receipts (alert_id, user_id)
    select ${id}, user_id from warehouse_members where warehouse_id = ${args.warehouseId}
  `;
  const alert: StockAlert = {
    id,
    item_id: args.item.id,
    item_code: args.item.code,
    item_name: args.item.name,
    unit: args.item.unit,
    qty_after: args.item.qty,
    min_qty: args.item.min_qty,
    message,
    recipients: recipients.join(", "),
    created_at: new Date().toISOString(),
  };
  const line: MailLine = {
    code: alert.item_code,
    name: alert.item_name,
    qty: alert.qty_after,
    min: alert.min_qty,
    unit: alert.unit,
  };
  return { threshold_hit: true, alert, mailto: buildMailto(recipients, [line]) };
}

function makeJoinCode() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = crypto.getRandomValues(new Uint8Array(6));
  let out = "";
  for (const byte of bytes) out += alphabet[byte % alphabet.length];
  return out;
}

const idSchema = z.string().trim().min(8, "Identificativo non valido.").max(80);
const emailSchema = z
  .string()
  .trim()
  .max(120)
  .refine((value) => value === "" || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value), "Mail non valida.");

export const listWarehouses = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Warehouse[]> => {
    const sql = await getSql();
    await actor(sql, context.userId);
    const rows = await sql<{
      id: string;
      name: string;
      join_code: string;
      notify_email: string;
      role: string;
      created_at: string | Date;
    }>`
      select w.id, w.name, w.join_code, w.notify_email, m.role, w.created_at
      from warehouses w
      join warehouse_members m on m.warehouse_id = w.id and m.user_id = ${context.userId}
      order by w.created_at desc
    `;
    return rows.map((row) => ({
      id: row.id,
      name: row.name,
      join_code: row.join_code,
      notify_email: row.notify_email ?? "",
      role: row.role,
      created_at: iso(row.created_at),
    }));
  });

export const createWarehouse = createServerFn({ method: "POST" })
  .validator(
    parse(
      z.object({
        name: z.string().trim().min(2, "Dai un nome al magazzino.").max(60),
        notifyEmail: emailSchema,
      }),
    ),
  )
  .middleware([authMiddleware])
  .handler(async ({ data, context }): Promise<Warehouse> => {
    const sql = await getSql();
    const who = await actor(sql, context.userId);
    const id = crypto.randomUUID();
    let joinCode = makeJoinCode();
    for (let attempt = 0; attempt < 5; attempt += 1) {
      try {
        await sql`
          insert into warehouses (id, name, join_code, created_by, notify_email)
          values (${id}, ${data.name}, ${joinCode}, ${context.userId}, ${data.notifyEmail.toLowerCase()})
        `;
        break;
      } catch (error) {
        if (!isUnique(error) || attempt === 4) throw error;
        joinCode = makeJoinCode();
      }
    }
    await sql`
      insert into warehouse_members (warehouse_id, user_id, email, display_name, role)
      values (${id}, ${context.userId}, ${who.email}, ${who.name}, 'owner')
    `;
    return {
      id,
      name: data.name,
      join_code: joinCode,
      notify_email: data.notifyEmail.toLowerCase(),
      role: "owner",
      created_at: new Date().toISOString(),
    };
  });

export const joinWarehouse = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const data = parse(z.object({ code: z.string().trim().min(1, "Inserisci il codice.") }))(input);
    const code = normalizeJoin(data.code);
    if (code.length < 4) throw new Error("Codice non valido.");
    return { code };
  })
  .middleware([authMiddleware])
  .handler(async ({ data, context }): Promise<Warehouse> => {
    const sql = await getSql();
    const who = await actor(sql, context.userId);
    const found = await sql<{
      id: string;
      name: string;
      join_code: string;
      notify_email: string;
      created_at: string | Date;
    }>`
      select id, name, join_code, notify_email, created_at
      from warehouses
      where join_code = ${data.code}
    `;
    const warehouse = found[0];
    if (!warehouse) throw new Error("Nessun magazzino con questo codice.");
    await sql`
      insert into warehouse_members (warehouse_id, user_id, email, display_name, role)
      values (${warehouse.id}, ${context.userId}, ${who.email}, ${who.name}, 'member')
      on conflict (warehouse_id, user_id) do update
      set email = excluded.email, display_name = excluded.display_name
    `;
    const roleRows = await sql<{ role: string }>`
      select role from warehouse_members
      where warehouse_id = ${warehouse.id} and user_id = ${context.userId}
    `;
    return {
      id: warehouse.id,
      name: warehouse.name,
      join_code: warehouse.join_code,
      notify_email: warehouse.notify_email ?? "",
      role: roleRows[0]?.role ?? "member",
      created_at: iso(warehouse.created_at),
    };
  });

export const updateNotifyEmail = createServerFn({ method: "POST" })
  .validator(
    parse(
      z.object({
        warehouseId: idSchema,
        notifyEmail: emailSchema,
      }),
    ),
  )
  .middleware([authMiddleware])
  .handler(async ({ data, context }) => {
    const sql = await getSql();
    await requireMember(sql, data.warehouseId, context.userId);
    const email = data.notifyEmail.toLowerCase();
    const rows = await sql<{ notify_email: string }>`
      update warehouses
      set notify_email = ${email}
      where id = ${data.warehouseId}
      returning notify_email
    `;
    return { notify_email: rows[0]?.notify_email ?? email };
  });

export const listMembers = createServerFn({ method: "POST" })
  .validator(parse(z.object({ warehouseId: idSchema })))
  .middleware([authMiddleware])
  .handler(async ({ data, context }): Promise<Member[]> => {
    const sql = await getSql();
    await requireMember(sql, data.warehouseId, context.userId);
    await actor(sql, context.userId);
    return sql<Member>`
      select user_id, email, display_name, role
      from warehouse_members
      where warehouse_id = ${data.warehouseId}
      order by case when role = 'owner' then 0 else 1 end, display_name asc
    `;
  });

export const leaveWarehouse = createServerFn({ method: "POST" })
  .validator(parse(z.object({ warehouseId: idSchema })))
  .middleware([authMiddleware])
  .handler(async ({ data, context }) => {
    const sql = await getSql();
    const role = await requireMember(sql, data.warehouseId, context.userId);
    if (role === "owner") {
      throw new Error("Chi ha creato il magazzino non può uscire. Puoi eliminarlo.");
    }
    await sql`
      delete from warehouse_members
      where warehouse_id = ${data.warehouseId} and user_id = ${context.userId}
    `;
    return { ok: true as const };
  });

export const deleteWarehouse = createServerFn({ method: "POST" })
  .validator(parse(z.object({ warehouseId: idSchema })))
  .middleware([authMiddleware])
  .handler(async ({ data, context }) => {
    const sql = await getSql();
    const role = await requireMember(sql, data.warehouseId, context.userId);
    if (role !== "owner") throw new Error("Solo chi ha creato il magazzino può eliminarlo.");
    await sql`delete from warehouses where id = ${data.warehouseId}`;
    return { ok: true as const };
  });

export const listItems = createServerFn({ method: "POST" })
  .validator(parse(z.object({ warehouseId: idSchema })))
  .middleware([authMiddleware])
  .handler(async ({ data, context }): Promise<Item[]> => {
    const sql = await getSql();
    await requireMember(sql, data.warehouseId, context.userId);
    const rows = await sql<ItemRow>`
      select id, warehouse_id, code, name, unit, qty, min_qty, location, updated_at
      from items
      where warehouse_id = ${data.warehouseId}
      order by (qty <= min_qty) desc, lower(name) asc
    `;
    return rows.map(mapItem);
  });

export const lookupItem = createServerFn({ method: "POST" })
  .validator(
    parse(
      z.object({
        warehouseId: idSchema,
        code: z.string().trim().min(1, "Inserisci il codice.").max(64),
      }),
    ),
  )
  .middleware([authMiddleware])
  .handler(async ({ data, context }): Promise<{ item: Item | null }> => {
    const sql = await getSql();
    await requireMember(sql, data.warehouseId, context.userId);
    const code = normalizeItemCode(data.code);
    const rows = await sql<ItemRow>`
      select id, warehouse_id, code, name, unit, qty, min_qty, location, updated_at
      from items
      where warehouse_id = ${data.warehouseId} and code = ${code}
    `;
    return { item: rows[0] ? mapItem(rows[0]) : null };
  });

const itemInput = z.object({
  warehouseId: idSchema,
  id: z.string().trim().min(8).max(80).nullable(),
  code: z.string().trim().min(1, "Inserisci il codice.").max(64),
  name: z.string().trim().min(1, "Inserisci il nome.").max(80),
  unit: z.string().trim().min(1, "Indica l'unità.").max(16),
  qty: z.number().finite().min(0, "La giacenza non può essere negativa.").max(1_000_000_000),
  minQty: z.number().finite().min(0, "La soglia non può essere negativa.").max(1_000_000_000),
  location: z.string().trim().max(80),
});

export const saveItem = createServerFn({ method: "POST" })
  .validator(parse(itemInput))
  .middleware([authMiddleware])
  .handler(async ({ data, context }): Promise<StockChange> => {
    const sql = await getSql();
    await requireMember(sql, data.warehouseId, context.userId);
    const who = await actor(sql, context.userId);
    const code = normalizeItemCode(data.code);
    if (!code) throw new Error("Inserisci il codice.");
    const qty = round3(data.qty);
    const minQty = round3(data.minQty);
    const name = data.name.trim();
    const unit = data.unit.trim();
    const location = data.location.trim();

    if (!data.id) {
      const id = crypto.randomUUID();
      try {
        await sql`
          insert into items (id, warehouse_id, code, name, unit, qty, min_qty, location)
          values (${id}, ${data.warehouseId}, ${code}, ${name}, ${unit}, ${qty}, ${minQty}, ${location})
        `;
      } catch (error) {
        if (isUnique(error)) throw new Error("Esiste già un articolo con questo codice.");
        throw error;
      }
      await sql`
        insert into movements (
          id, warehouse_id, item_id, item_code, item_name, user_id, actor_name,
          kind, qty, qty_before, qty_after, note
        ) values (
          ${crypto.randomUUID()}, ${data.warehouseId}, ${id}, ${code}, ${name},
          ${context.userId}, ${who.name}, 'rettifica', ${qty}, ${0}, ${qty}, 'Giacenza iniziale'
        )
      `;
      const item = await loadItem(sql, data.warehouseId, id);
      if (!item) throw new Error("Articolo non salvato.");
      return { item, threshold_hit: false, alert: null, mailto: null };
    }

    const prev = await loadItem(sql, data.warehouseId, data.id);
    if (!prev) throw new Error("Articolo non trovato.");
    try {
      await sql`
        update items
        set code = ${code},
            name = ${name},
            unit = ${unit},
            qty = ${qty},
            min_qty = ${minQty},
            location = ${location},
            updated_at = now()
        where id = ${data.id} and warehouse_id = ${data.warehouseId}
      `;
    } catch (error) {
      if (isUnique(error)) throw new Error("Esiste già un articolo con questo codice.");
      throw error;
    }
    if (prev.qty !== qty) {
      await sql`
        insert into movements (
          id, warehouse_id, item_id, item_code, item_name, user_id, actor_name,
          kind, qty, qty_before, qty_after, note
        ) values (
          ${crypto.randomUUID()}, ${data.warehouseId}, ${data.id}, ${code}, ${name},
          ${context.userId}, ${who.name}, 'rettifica', ${qty}, ${prev.qty}, ${qty}, 'Correzione giacenza'
        )
      `;
    }
    const item = await loadItem(sql, data.warehouseId, data.id);
    if (!item) throw new Error("Articolo non trovato.");
    const raised = await raiseAlert(sql, {
      warehouseId: data.warehouseId,
      item,
      qtyBefore: prev.qty,
      minBefore: prev.min_qty,
    });
    return { item, ...raised };
  });

export const deleteItem = createServerFn({ method: "POST" })
  .validator(parse(z.object({ warehouseId: idSchema, itemId: idSchema })))
  .middleware([authMiddleware])
  .handler(async ({ data, context }) => {
    const sql = await getSql();
    await requireMember(sql, data.warehouseId, context.userId);
    await sql`
      delete from alerts
      where warehouse_id = ${data.warehouseId} and item_id = ${data.itemId}
    `;
    const rows = await sql<{ id: string }>`
      delete from items
      where id = ${data.itemId} and warehouse_id = ${data.warehouseId}
      returning id
    `;
    if (!rows[0]) throw new Error("Articolo non trovato.");
    return { ok: true as const };
  });

export const recordMove = createServerFn({ method: "POST" })
  .validator(
    parse(
      z.object({
        warehouseId: idSchema,
        itemId: idSchema,
        kind: z.enum(["prelievo", "carico"]),
        qty: z.number().finite().gt(0, "Inserisci una quantità maggiore di zero.").max(1_000_000_000),
        note: z.string().trim().max(200),
      }),
    ),
  )
  .middleware([authMiddleware])
  .handler(async ({ data, context }): Promise<StockChange> => {
    const sql = await getSql();
    await requireMember(sql, data.warehouseId, context.userId);
    const who = await actor(sql, context.userId);
    const prev = await loadItem(sql, data.warehouseId, data.itemId);
    if (!prev) throw new Error("Articolo non trovato.");
    const delta = round3(data.qty);
    if (data.kind === "prelievo" && delta > prev.qty + 1e-9) {
      throw new Error(`Giacenza insufficiente: disponibili ${formatQty(prev.qty)} ${prev.unit}.`);
    }
    const nextQty = data.kind === "prelievo" ? round3(prev.qty - delta) : round3(prev.qty + delta);
    await sql`
      update items
      set qty = ${nextQty}, updated_at = now()
      where id = ${prev.id} and warehouse_id = ${data.warehouseId}
    `;
    await sql`
      insert into movements (
        id, warehouse_id, item_id, item_code, item_name, user_id, actor_name,
        kind, qty, qty_before, qty_after, note
      ) values (
        ${crypto.randomUUID()},
        ${data.warehouseId},
        ${prev.id},
        ${prev.code},
        ${prev.name},
        ${context.userId},
        ${who.name},
        ${data.kind},
        ${delta},
        ${prev.qty},
        ${nextQty},
        ${data.note}
      )
    `;
    const item = await loadItem(sql, data.warehouseId, prev.id);
    if (!item) throw new Error("Articolo non trovato.");
    const raised = await raiseAlert(sql, {
      warehouseId: data.warehouseId,
      item,
      qtyBefore: prev.qty,
      minBefore: prev.min_qty,
    });
    return { item, ...raised };
  });

export const listMovements = createServerFn({ method: "POST" })
  .validator(parse(z.object({ warehouseId: idSchema, itemId: z.string().trim().max(80).nullable() })))
  .middleware([authMiddleware])
  .handler(async ({ data, context }): Promise<Movement[]> => {
    const sql = await getSql();
    await requireMember(sql, data.warehouseId, context.userId);
    const rows = data.itemId
      ? await sql<Movement>`
          select id, item_id, item_code, item_name, actor_name, kind, qty, qty_before, qty_after, note, created_at
          from movements
          where warehouse_id = ${data.warehouseId} and item_id = ${data.itemId}
          order by created_at desc
          limit 40
        `
      : await sql<Movement>`
          select id, item_id, item_code, item_name, actor_name, kind, qty, qty_before, qty_after, note, created_at
          from movements
          where warehouse_id = ${data.warehouseId}
          order by created_at desc
          limit 60
        `;
    return rows.map((row) => ({
      ...row,
      qty: num(row.qty),
      qty_before: num(row.qty_before),
      qty_after: num(row.qty_after),
      note: row.note ?? "",
      created_at: iso(row.created_at),
    }));
  });

export const listAlerts = createServerFn({ method: "POST" })
  .validator(parse(z.object({ warehouseId: idSchema })))
  .middleware([authMiddleware])
  .handler(async ({ data, context }): Promise<StockAlert[]> => {
    const sql = await getSql();
    await requireMember(sql, data.warehouseId, context.userId);
    const rows = await sql<StockAlert>`
      select a.id, a.item_id, a.item_code, a.item_name, a.unit,
             a.qty_after, a.min_qty, a.message, a.recipients, a.created_at
      from alerts a
      join alert_receipts r on r.alert_id = a.id and r.user_id = ${context.userId}
      where a.warehouse_id = ${data.warehouseId} and r.acked_at is null
      order by a.created_at desc
      limit 30
    `;
    return rows.map((row) => ({
      ...row,
      qty_after: num(row.qty_after),
      min_qty: num(row.min_qty),
      recipients: row.recipients ?? "",
      created_at: iso(row.created_at),
    }));
  });

export const ackAlerts = createServerFn({ method: "POST" })
  .validator(parse(z.object({ warehouseId: idSchema })))
  .middleware([authMiddleware])
  .handler(async ({ data, context }) => {
    const sql = await getSql();
    await requireMember(sql, data.warehouseId, context.userId);
    await sql`
      update alert_receipts r
      set acked_at = now()
      from alerts a
      where r.alert_id = a.id
        and a.warehouse_id = ${data.warehouseId}
        and r.user_id = ${context.userId}
        and r.acked_at is null
    `;
    return { ok: true as const };
  });
