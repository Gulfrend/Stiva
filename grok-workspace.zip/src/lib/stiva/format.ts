export const WAREHOUSE_KEY = "stiva.warehouse";
export const AUTO_MAIL_KEY = "stiva.autoMail";
export const SEEN_KEY = "stiva.seenAlerts";

export const UNITS = ["pz", "kg", "g", "lt", "ml", "m", "cm", "conf", "scatola", "rotolo"] as const;

export type MailLine = {
  code: string;
  name: string;
  qty: number;
  min: number;
  unit: string;
};

export function round3(n: number) {
  return Math.round(n * 1000) / 1000;
}

export function num(v: unknown): number {
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? round3(n) : 0;
}

export function iso(v: unknown): string {
  if (v instanceof Date && !Number.isNaN(v.getTime())) return v.toISOString();
  if (typeof v === "string" && v) {
    const d = new Date(v);
    if (!Number.isNaN(d.getTime())) return d.toISOString();
    return v;
  }
  return new Date().toISOString();
}

export function formatQty(n: number) {
  return new Intl.NumberFormat("it-IT", { maximumFractionDigits: 3 }).format(round3(n));
}

export function formatQtyInput(n: number) {
  return String(round3(n)).replace(".", ",");
}

export function formatWhen(isoText: string) {
  const d = new Date(isoText);
  if (Number.isNaN(d.getTime())) return "";
  return new Intl.DateTimeFormat("it-IT", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  }).format(d);
}

export function parseQty(raw: string): number | null {
  const t = raw.trim().replace(/\s/g, "").replace(",", ".");
  if (!t) return null;
  const n = Number(t);
  if (!Number.isFinite(n) || n < 0) return null;
  return round3(n);
}

export function isLow(qty: number, min: number) {
  return qty <= min;
}

export function normalizeJoin(raw: string) {
  return raw.replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
}

export function normalizeItemCode(raw: string) {
  return raw.trim().replace(/\s+/g, "").toUpperCase();
}

export function formatJoin(code: string) {
  const clean = normalizeJoin(code);
  if (clean.length !== 6) return clean;
  return `${clean.slice(0, 3)}-${clean.slice(3)}`;
}

export function extractCode(raw: string) {
  const text = raw.trim();
  if (!text) return "";
  try {
    const url = new URL(text);
    const fromQuery = url.searchParams.get("code") || url.searchParams.get("c");
    if (fromQuery) return normalizeItemCode(fromQuery);
    const parts = url.pathname.split("/").filter(Boolean);
    const last = parts[parts.length - 1];
    if (last) return normalizeItemCode(decodeURIComponent(last));
  } catch {
    /* plain code or barcode */
  }
  const stripped = text.replace(/^(?:STIVA:|ITEM:)/i, "");
  return normalizeItemCode(stripped);
}

export function buildMailto(emails: string[], lines: MailLine[]): string | null {
  const unique = [
    ...new Set(emails.map((e) => e.trim().toLowerCase()).filter((e) => e.includes("@"))),
  ];
  if (!unique.length || !lines.length) return null;
  const subject =
    lines.length === 1
      ? `Stiva · sotto soglia: ${lines[0].code}`
      : `Stiva · ${lines.length} articoli sotto soglia`;
  const body = [
    "Avviso di giacenza — Stiva",
    "",
    ...lines.map(
      (line) =>
        `${line.code} — ${line.name}: ${formatQty(line.qty)} ${line.unit} (soglia ${formatQty(line.min)} ${line.unit})`,
    ),
    "",
    "La scorta è sotto la soglia minima. Rifornisci il magazzino.",
  ].join("\n");
  return `mailto:${unique.join(",")}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

export function readSeen(): Set<string> {
  if (typeof window === "undefined") return new Set();
  try {
    const parsed = JSON.parse(localStorage.getItem(SEEN_KEY) || "[]") as unknown;
    if (!Array.isArray(parsed)) return new Set();
    return new Set(parsed.filter((item): item is string => typeof item === "string"));
  } catch {
    return new Set();
  }
}

export function markAlertsSeen(ids: string[]) {
  if (typeof window === "undefined" || !ids.length) return;
  const seen = readSeen();
  for (const id of ids) seen.add(id);
  localStorage.setItem(SEEN_KEY, JSON.stringify([...seen].slice(-200)));
}
