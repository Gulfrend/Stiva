//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Do0FD-4j.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/login",
			"/join/$code",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-BhIxKdZL.js",
			"/assets/rolldown-runtime-hePW80VL.js",
			"/assets/react-Cvdyeg_0.js",
			"/assets/createClientRpc-B2Uy9AxG.js",
			"/assets/preload-helper-8lnFcbHh.js",
			"/assets/lazyRouteComponent-CeP7L6S1.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BhIxKdZL.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CM1euOO6.js",
			"/assets/format-I_yJDHwI.js",
			"/assets/login-panel-B3TPHM3A.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-DYVVOdNg.js", "/assets/login-panel-B3TPHM3A.js"]
	},
	"/join/$code": {
		filePath: "/workspace/src/routes/join/$code.tsx",
		children: void 0,
		preloads: [
			"/assets/_code-CB3LStYO.js",
			"/assets/format-I_yJDHwI.js",
			"/assets/login-panel-B3TPHM3A.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
