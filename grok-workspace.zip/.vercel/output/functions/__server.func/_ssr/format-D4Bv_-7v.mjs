import { n as createMiddleware } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/format-D4Bv_-7v.js
/**
* Auth middleware for server functions — the standard way to get the caller's
* verified user id. When deployed the session cookie is same-origin and rides
* along automatically. In the live preview the client also forwards the bearer
* token (partitioned cookies) via the `.client` hook below — call sites do not
* thread it themselves.
*
*   import { createServerFn } from "@tanstack/react-start";
*   import { getSql } from "@/lib/db";
*   import { authMiddleware } from "@/lib/auth/middleware";
*
*   export const listTodos = createServerFn({ method: "GET" })
*     .middleware([authMiddleware])
*     .handler(async ({ context }) => {
*       const sql = await getSql();
*       return sql`select * from todos where user_id = ${context.userId}`;
*     });
*
* Signed out with auth on (live preview included) -> throws `UnauthorizedError`
* (see `verify.server.ts`). With auth disabled (`VITE_AUTH_ENABLED=false`, the
* shipped default) it resolves the shared dev user — but throws instead when a
* `DATABASE_URL` is also set, so an app without sign-in must not use this at
* all. On the auth-on path, use it on every server function that touches
* per-user data and scope every query by `context.userId`.
*/
var authMiddleware = createMiddleware({ type: "function" }).client(async ({ next }) => {
	const { getBearerToken } = await import("./client-1vAx-gM_.mjs").then((n) => n.n).then((n) => n.n);
	return next({ sendContext: { bearerToken: getBearerToken() ?? void 0 } });
}).server(async ({ next, context }) => {
	const { assertSameSiteRequest } = await import("./isolation.server-CGNg1r0B.mjs");
	const { requireUserId } = await import("./verify.server-CWFyEduz.mjs");
	assertSameSiteRequest();
	return next({ context: { userId: await requireUserId(context.bearerToken) } });
});
var WAREHOUSE_KEY = "stiva.warehouse";
var AUTO_MAIL_KEY = "stiva.autoMail";
var SEEN_KEY = "stiva.seenAlerts";
var UNITS = [
	"pz",
	"kg",
	"g",
	"lt",
	"ml",
	"m",
	"cm",
	"conf",
	"scatola",
	"rotolo"
];
function round3(n) {
	return Math.round(n * 1e3) / 1e3;
}
function num(v) {
	const n = typeof v === "number" ? v : Number(v);
	return Number.isFinite(n) ? round3(n) : 0;
}
function iso(v) {
	if (v instanceof Date && !Number.isNaN(v.getTime())) return v.toISOString();
	if (typeof v === "string" && v) {
		const d = new Date(v);
		if (!Number.isNaN(d.getTime())) return d.toISOString();
		return v;
	}
	return (/* @__PURE__ */ new Date()).toISOString();
}
function formatQty(n) {
	return new Intl.NumberFormat("it-IT", { maximumFractionDigits: 3 }).format(round3(n));
}
function formatQtyInput(n) {
	return String(round3(n)).replace(".", ",");
}
function formatWhen(isoText) {
	const d = new Date(isoText);
	if (Number.isNaN(d.getTime())) return "";
	return new Intl.DateTimeFormat("it-IT", {
		day: "2-digit",
		month: "short",
		hour: "2-digit",
		minute: "2-digit"
	}).format(d);
}
function parseQty(raw) {
	const t = raw.trim().replace(/\s/g, "").replace(",", ".");
	if (!t) return null;
	const n = Number(t);
	if (!Number.isFinite(n) || n < 0) return null;
	return round3(n);
}
function isLow(qty, min) {
	return qty <= min;
}
function normalizeJoin(raw) {
	return raw.replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
}
function normalizeItemCode(raw) {
	return raw.trim().replace(/\s+/g, "").toUpperCase();
}
function formatJoin(code) {
	const clean = normalizeJoin(code);
	if (clean.length !== 6) return clean;
	return `${clean.slice(0, 3)}-${clean.slice(3)}`;
}
function extractCode(raw) {
	const text = raw.trim();
	if (!text) return "";
	try {
		const url = new URL(text);
		const fromQuery = url.searchParams.get("code") || url.searchParams.get("c");
		if (fromQuery) return normalizeItemCode(fromQuery);
		const parts = url.pathname.split("/").filter(Boolean);
		const last = parts[parts.length - 1];
		if (last) return normalizeItemCode(decodeURIComponent(last));
	} catch {}
	return normalizeItemCode(text.replace(/^(?:STIVA:|ITEM:)/i, ""));
}
function buildMailto(emails, lines) {
	const unique = [...new Set(emails.map((e) => e.trim().toLowerCase()).filter((e) => e.includes("@")))];
	if (!unique.length || !lines.length) return null;
	const subject = lines.length === 1 ? `Stiva · sotto soglia: ${lines[0].code}` : `Stiva · ${lines.length} articoli sotto soglia`;
	const body = [
		"Avviso di giacenza — Stiva",
		"",
		...lines.map((line) => `${line.code} — ${line.name}: ${formatQty(line.qty)} ${line.unit} (soglia ${formatQty(line.min)} ${line.unit})`),
		"",
		"La scorta è sotto la soglia minima. Rifornisci il magazzino."
	].join("\n");
	return `mailto:${unique.join(",")}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}
function readSeen() {
	if (typeof window === "undefined") return /* @__PURE__ */ new Set();
	try {
		const parsed = JSON.parse(localStorage.getItem("stiva.seenAlerts") || "[]");
		if (!Array.isArray(parsed)) return /* @__PURE__ */ new Set();
		return new Set(parsed.filter((item) => typeof item === "string"));
	} catch {
		return /* @__PURE__ */ new Set();
	}
}
function markAlertsSeen(ids) {
	if (typeof window === "undefined" || !ids.length) return;
	const seen = readSeen();
	for (const id of ids) seen.add(id);
	localStorage.setItem(SEEN_KEY, JSON.stringify([...seen].slice(-200)));
}
//#endregion
export { parseQty as _, buildMailto as a, formatQty as c, isLow as d, iso as f, num as g, normalizeJoin as h, authMiddleware as i, formatQtyInput as l, normalizeItemCode as m, UNITS as n, extractCode as o, markAlertsSeen as p, WAREHOUSE_KEY as r, formatJoin as s, AUTO_MAIL_KEY as t, formatWhen as u, readSeen as v, round3 as y };
