import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { r as Route$2 } from "./router-BErZIEja.mjs";
import { i as useCurrentUserState, n as LoginPanel, t as BootScreen } from "./login-panel-J-UwXrSk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-I0QnWiKU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LoginPage() {
	const { next } = Route$2.useSearch();
	const { user, isPending } = useCurrentUserState();
	(0, import_react.useEffect)(() => {
		if (!isPending && user) window.location.replace(next);
	}, [
		isPending,
		next,
		user
	]);
	if (isPending || user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoginPanel, { next });
}
//#endregion
export { LoginPage as component };
