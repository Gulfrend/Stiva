import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as GROK_PROVIDERS } from "./server-_FnbRQv7.mjs";
import { r as signIn, t as authClient } from "./client-1vAx-gM_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-panel-J-UwXrSk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	return useSessionUserState();
}
function useSessionUserState() {
	const { data, isPending } = authClient.useSession();
	const id = data?.user.id;
	const displayName = data?.user.name ?? null;
	const primaryEmail = data?.user.email ?? null;
	const profileImageUrl = data?.user.image ?? null;
	const user = (0, import_react.useMemo)(() => id ? {
		id,
		displayName,
		primaryEmail,
		profileImageUrl,
		isDevFallback: false
	} : null, [
		id,
		displayName,
		primaryEmail,
		profileImageUrl
	]);
	return (0, import_react.useMemo)(() => ({
		user,
		isPending
	}), [user, isPending]);
}
/**
* Convenience view of `useCurrentUserState().user` for display (e.g.
* `user?.displayName ?? "Guest"`). NOTE: `null` means *loading OR signed out* —
* for redirects/guards use `useCurrentUserState()` and check `isPending`.
*/
function useCurrentUser() {
	return useCurrentUserState().user;
}
function mapAuthError(message) {
	const text = (message ?? "").toLowerCase();
	if (text.includes("already") || text.includes("exist")) return "Esiste già un account con questa mail.";
	if (text.includes("short") || text.includes("least")) return "La password deve avere almeno 8 caratteri.";
	if (text.includes("invalid") || text.includes("credential") || text.includes("incorrect")) return "Mail o password non corrette.";
	return message || "Accesso non riuscito. Riprova.";
}
function BootScreen({ label = "Stiva" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center bg-bg px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "eyebrow",
				children: "Magazzino"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "wordmark text-3xl",
				children: label
			})]
		})
	});
}
function LoginPanel({ next = "/" }) {
	const [mode, setMode] = (0, import_react.useState)("in");
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [pending, setPending] = (0, import_react.useState)(false);
	async function submit(event) {
		event.preventDefault();
		setError(null);
		setPending(true);
		try {
			if (mode === "up") {
				const result = await authClient.signUp.email({
					email,
					password,
					name: name.trim()
				});
				if (result.error) throw new Error(result.error.message);
			} else {
				const result = await authClient.signIn.email({
					email,
					password
				});
				if (result.error) throw new Error(result.error.message);
			}
			window.location.assign(next);
		} catch (caught) {
			setError(mapAuthError(caught instanceof Error ? caught.message : void 0));
			setPending(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-screen w-full max-w-xl flex-col justify-center bg-bg px-5 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "eyebrow",
				children: "Magazzino condiviso"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-4xl font-semibold tracking-tight",
				children: "Stiva"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "lede mt-3 max-w-md",
				children: "Inserisci i codici, tieni le quantità e preleva leggendo il QR. Sotto la soglia parte l'avviso a schermo e la mail per il gruppo."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "card stack mt-8",
				onSubmit: (event) => void submit(event),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: mode === "up" ? "Crea l'account" : "Entra"
					}),
					mode === "up" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Nome" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "login-name",
							required: true,
							autoComplete: "name",
							value: name,
							placeholder: "Come ti vedono in squadra",
							onChange: (event) => setName(event.target.value)
						})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Mail" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "login-email",
							type: "email",
							required: true,
							autoComplete: "email",
							value: email,
							onChange: (event) => setEmail(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Password" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "login-password",
							type: "password",
							required: true,
							minLength: 8,
							autoComplete: mode === "up" ? "new-password" : "current-password",
							value: password,
							onChange: (event) => setPassword(event.target.value)
						})]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "note note-danger",
						role: "alert",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn btn-primary w-full",
						type: "submit",
						disabled: pending,
						children: pending ? "Attendi…" : mode === "up" ? "Crea account" : "Entra"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-sm font-medium text-muted",
						onClick: () => {
							setMode(mode === "up" ? "in" : "up");
							setError(null);
						},
						children: mode === "up" ? "Hai già un account? Entra" : "Nuovo qui? Crea un account"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "stack mt-4",
				children: GROK_PROVIDERS.map((provider) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "btn btn-ghost w-full",
					onClick: () => {
						setError(null);
						signIn(provider.providerId, { callbackURL: next }).catch((caught) => {
							setError(caught instanceof Error ? caught.message : "Accesso non riuscito.");
						});
					},
					children: ["Continua con ", provider.label]
				}, provider.providerId))
			})
		]
	});
}
//#endregion
export { useCurrentUserState as i, LoginPanel as n, useCurrentUser as r, BootScreen as t };
