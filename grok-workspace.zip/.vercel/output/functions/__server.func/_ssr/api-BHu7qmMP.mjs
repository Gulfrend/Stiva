import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { a as buildMailto, c as formatQty, f as iso, g as num, h as normalizeJoin, i as authMiddleware, m as normalizeItemCode, y as round3 } from "./format-D4Bv_-7v.mjs";
import { D as _enum, F as object, P as number, R as string } from "../_libs/@better-auth/core+[...].mjs";
import { r as getSql } from "./db-DgA3slAb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-BHu7qmMP.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function parse(schema) {
	return (input) => {
		const result = schema.safeParse(input);
		if (!result.success) throw new Error(result.error.issues[0]?.message ?? "Dati non validi.");
		return result.data;
	};
}
function isUnique(error) {
	if (typeof error === "object" && error !== null && "code" in error && error.code === "23505") return true;
	const msg = error instanceof Error ? error.message : String(error);
	return /unique|duplicate/i.test(msg);
}
function mapItem(row) {
	return {
		id: row.id,
		warehouse_id: row.warehouse_id,
		code: row.code,
		name: row.name,
		unit: row.unit,
		qty: num(row.qty),
		min_qty: num(row.min_qty),
		location: row.location ?? "",
		updated_at: iso(row.updated_at)
	};
}
async function actor(sql, userId) {
	const rows = await sql`
    select "name" as name, "email" as email from "user" where "id" = ${userId}
  `;
	const name = rows[0]?.name?.trim() || "Operatore";
	const email = rows[0]?.email?.trim().toLowerCase() || "";
	await sql`
    update warehouse_members
    set display_name = ${name}, email = ${email}
    where user_id = ${userId}
  `;
	return {
		name,
		email
	};
}
async function requireMember(sql, warehouseId, userId) {
	const rows = await sql`
    select role from warehouse_members
    where warehouse_id = ${warehouseId} and user_id = ${userId}
  `;
	if (!rows[0]) throw new Error("Non hai accesso a questo magazzino.");
	return rows[0].role;
}
async function loadItem(sql, warehouseId, id) {
	const rows = await sql`
    select id, warehouse_id, code, name, unit, qty, min_qty, location, updated_at
    from items
    where id = ${id} and warehouse_id = ${warehouseId}
  `;
	return rows[0] ? mapItem(rows[0]) : null;
}
async function raiseAlert(sql, args) {
	const wasAbove = args.qtyBefore > args.minBefore;
	const nowBelow = args.item.qty <= args.item.min_qty;
	if (!wasAbove || !nowBelow) return {
		threshold_hit: false,
		alert: null,
		mailto: null
	};
	const members = await sql`
    select m.email, w.notify_email
    from warehouse_members m
    join warehouses w on w.id = m.warehouse_id
    where m.warehouse_id = ${args.warehouseId}
  `;
	const emails = /* @__PURE__ */ new Set();
	for (const row of members) {
		if (row.email?.includes("@")) emails.add(row.email.trim().toLowerCase());
		if (row.notify_email?.includes("@")) emails.add(row.notify_email.trim().toLowerCase());
	}
	const recipients = [...emails];
	const message = `${args.item.name} (${args.item.code}) è a ${formatQty(args.item.qty)} ${args.item.unit}, sotto la soglia di ${formatQty(args.item.min_qty)} ${args.item.unit}.`;
	const id = crypto.randomUUID();
	await sql`
    insert into alerts (
      id, warehouse_id, item_id, item_code, item_name, unit,
      qty_after, min_qty, message, recipients
    ) values (
      ${id},
      ${args.warehouseId},
      ${args.item.id},
      ${args.item.code},
      ${args.item.name},
      ${args.item.unit},
      ${args.item.qty},
      ${args.item.min_qty},
      ${message},
      ${recipients.join(", ")}
    )
  `;
	await sql`
    insert into alert_receipts (alert_id, user_id)
    select ${id}, user_id from warehouse_members where warehouse_id = ${args.warehouseId}
  `;
	const alert = {
		id,
		item_id: args.item.id,
		item_code: args.item.code,
		item_name: args.item.name,
		unit: args.item.unit,
		qty_after: args.item.qty,
		min_qty: args.item.min_qty,
		message,
		recipients: recipients.join(", "),
		created_at: (/* @__PURE__ */ new Date()).toISOString()
	};
	const line = {
		code: alert.item_code,
		name: alert.item_name,
		qty: alert.qty_after,
		min: alert.min_qty,
		unit: alert.unit
	};
	return {
		threshold_hit: true,
		alert,
		mailto: buildMailto(recipients, [line])
	};
}
function makeJoinCode() {
	const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
	const bytes = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(6));
	let out = "";
	for (const byte of bytes) out += alphabet[byte % 32];
	return out;
}
var idSchema = string().trim().min(8, "Identificativo non valido.").max(80);
var emailSchema = string().trim().max(120).refine((value) => value === "" || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value), "Mail non valida.");
var listWarehouses_createServerFn_handler = createServerRpc({
	id: "3fa1b1382333e6252d52cfdbd94fd95ce6550b5f832b8c560e1c9325f7e55552",
	name: "listWarehouses",
	filename: "src/lib/stiva/api.ts"
}, (opts) => listWarehouses.__executeServer(opts));
var listWarehouses = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listWarehouses_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await actor(sql, context.userId);
	return (await sql`
      select w.id, w.name, w.join_code, w.notify_email, m.role, w.created_at
      from warehouses w
      join warehouse_members m on m.warehouse_id = w.id and m.user_id = ${context.userId}
      order by w.created_at desc
    `).map((row) => ({
		id: row.id,
		name: row.name,
		join_code: row.join_code,
		notify_email: row.notify_email ?? "",
		role: row.role,
		created_at: iso(row.created_at)
	}));
});
var createWarehouse_createServerFn_handler = createServerRpc({
	id: "09aa77ddb318b473e1941aa625db3ceb5672c64a5ded95e2a2ce6f52a803c892",
	name: "createWarehouse",
	filename: "src/lib/stiva/api.ts"
}, (opts) => createWarehouse.__executeServer(opts));
var createWarehouse = createServerFn({ method: "POST" }).validator(parse(object({
	name: string().trim().min(2, "Dai un nome al magazzino.").max(60),
	notifyEmail: emailSchema
}))).middleware([authMiddleware]).handler(createWarehouse_createServerFn_handler, async ({ data, context }) => {
	const sql = await getSql();
	const who = await actor(sql, context.userId);
	const id = crypto.randomUUID();
	let joinCode = makeJoinCode();
	for (let attempt = 0; attempt < 5; attempt += 1) try {
		await sql`
          insert into warehouses (id, name, join_code, created_by, notify_email)
          values (${id}, ${data.name}, ${joinCode}, ${context.userId}, ${data.notifyEmail.toLowerCase()})
        `;
		break;
	} catch (error) {
		if (!isUnique(error) || attempt === 4) throw error;
		joinCode = makeJoinCode();
	}
	await sql`
      insert into warehouse_members (warehouse_id, user_id, email, display_name, role)
      values (${id}, ${context.userId}, ${who.email}, ${who.name}, 'owner')
    `;
	return {
		id,
		name: data.name,
		join_code: joinCode,
		notify_email: data.notifyEmail.toLowerCase(),
		role: "owner",
		created_at: (/* @__PURE__ */ new Date()).toISOString()
	};
});
var joinWarehouse_createServerFn_handler = createServerRpc({
	id: "4d5a4c150f5a4c68287e5dfd5b7cef2bc1b57224c441fd3aedca2c0c05109c05",
	name: "joinWarehouse",
	filename: "src/lib/stiva/api.ts"
}, (opts) => joinWarehouse.__executeServer(opts));
var joinWarehouse = createServerFn({ method: "POST" }).validator((input) => {
	const data = parse(object({ code: string().trim().min(1, "Inserisci il codice.") }))(input);
	const code = normalizeJoin(data.code);
	if (code.length < 4) throw new Error("Codice non valido.");
	return { code };
}).middleware([authMiddleware]).handler(joinWarehouse_createServerFn_handler, async ({ data, context }) => {
	const sql = await getSql();
	const who = await actor(sql, context.userId);
	const warehouse = (await sql`
      select id, name, join_code, notify_email, created_at
      from warehouses
      where join_code = ${data.code}
    `)[0];
	if (!warehouse) throw new Error("Nessun magazzino con questo codice.");
	await sql`
      insert into warehouse_members (warehouse_id, user_id, email, display_name, role)
      values (${warehouse.id}, ${context.userId}, ${who.email}, ${who.name}, 'member')
      on conflict (warehouse_id, user_id) do update
      set email = excluded.email, display_name = excluded.display_name
    `;
	const roleRows = await sql`
      select role from warehouse_members
      where warehouse_id = ${warehouse.id} and user_id = ${context.userId}
    `;
	return {
		id: warehouse.id,
		name: warehouse.name,
		join_code: warehouse.join_code,
		notify_email: warehouse.notify_email ?? "",
		role: roleRows[0]?.role ?? "member",
		created_at: iso(warehouse.created_at)
	};
});
var updateNotifyEmail_createServerFn_handler = createServerRpc({
	id: "b40d7f4e7bc0568e17171d46eae987f4e9e64a195e596af592c6abe338e9fd9a",
	name: "updateNotifyEmail",
	filename: "src/lib/stiva/api.ts"
}, (opts) => updateNotifyEmail.__executeServer(opts));
var updateNotifyEmail = createServerFn({ method: "POST" }).validator(parse(object({
	warehouseId: idSchema,
	notifyEmail: emailSchema
}))).middleware([authMiddleware]).handler(updateNotifyEmail_createServerFn_handler, async ({ data, context }) => {
	const sql = await getSql();
	await requireMember(sql, data.warehouseId, context.userId);
	const email = data.notifyEmail.toLowerCase();
	return { notify_email: (await sql`
      update warehouses
      set notify_email = ${email}
      where id = ${data.warehouseId}
      returning notify_email
    `)[0]?.notify_email ?? email };
});
var listMembers_createServerFn_handler = createServerRpc({
	id: "92d51b00c001828afc013347420ccd502b402669325c1ceb90855bb5f770f125",
	name: "listMembers",
	filename: "src/lib/stiva/api.ts"
}, (opts) => listMembers.__executeServer(opts));
var listMembers = createServerFn({ method: "POST" }).validator(parse(object({ warehouseId: idSchema }))).middleware([authMiddleware]).handler(listMembers_createServerFn_handler, async ({ data, context }) => {
	const sql = await getSql();
	await requireMember(sql, data.warehouseId, context.userId);
	await actor(sql, context.userId);
	return sql`
      select user_id, email, display_name, role
      from warehouse_members
      where warehouse_id = ${data.warehouseId}
      order by case when role = 'owner' then 0 else 1 end, display_name asc
    `;
});
var leaveWarehouse_createServerFn_handler = createServerRpc({
	id: "59a1cedf7a8c7d458363c5db348812b23f7bd1365dcda8e5223a2cd4b6cfac57",
	name: "leaveWarehouse",
	filename: "src/lib/stiva/api.ts"
}, (opts) => leaveWarehouse.__executeServer(opts));
var leaveWarehouse = createServerFn({ method: "POST" }).validator(parse(object({ warehouseId: idSchema }))).middleware([authMiddleware]).handler(leaveWarehouse_createServerFn_handler, async ({ data, context }) => {
	const sql = await getSql();
	if (await requireMember(sql, data.warehouseId, context.userId) === "owner") throw new Error("Chi ha creato il magazzino non può uscire. Puoi eliminarlo.");
	await sql`
      delete from warehouse_members
      where warehouse_id = ${data.warehouseId} and user_id = ${context.userId}
    `;
	return { ok: true };
});
var deleteWarehouse_createServerFn_handler = createServerRpc({
	id: "c5eb5c7f8c776c22b5e82592553dbb23062b34991eefccc969143bd37a2f58ba",
	name: "deleteWarehouse",
	filename: "src/lib/stiva/api.ts"
}, (opts) => deleteWarehouse.__executeServer(opts));
var deleteWarehouse = createServerFn({ method: "POST" }).validator(parse(object({ warehouseId: idSchema }))).middleware([authMiddleware]).handler(deleteWarehouse_createServerFn_handler, async ({ data, context }) => {
	const sql = await getSql();
	if (await requireMember(sql, data.warehouseId, context.userId) !== "owner") throw new Error("Solo chi ha creato il magazzino può eliminarlo.");
	await sql`delete from warehouses where id = ${data.warehouseId}`;
	return { ok: true };
});
var listItems_createServerFn_handler = createServerRpc({
	id: "e97e2bc60500b0f46a4dbafb1826875671ce68763ccdeea22f9b74902fb102bc",
	name: "listItems",
	filename: "src/lib/stiva/api.ts"
}, (opts) => listItems.__executeServer(opts));
var listItems = createServerFn({ method: "POST" }).validator(parse(object({ warehouseId: idSchema }))).middleware([authMiddleware]).handler(listItems_createServerFn_handler, async ({ data, context }) => {
	const sql = await getSql();
	await requireMember(sql, data.warehouseId, context.userId);
	return (await sql`
      select id, warehouse_id, code, name, unit, qty, min_qty, location, updated_at
      from items
      where warehouse_id = ${data.warehouseId}
      order by (qty <= min_qty) desc, lower(name) asc
    `).map(mapItem);
});
var lookupItem_createServerFn_handler = createServerRpc({
	id: "5ea019172f022b2b124cf2ccc3392c6043a0bcc5a94a5af0e46b08cf3bcc66e3",
	name: "lookupItem",
	filename: "src/lib/stiva/api.ts"
}, (opts) => lookupItem.__executeServer(opts));
var lookupItem = createServerFn({ method: "POST" }).validator(parse(object({
	warehouseId: idSchema,
	code: string().trim().min(1, "Inserisci il codice.").max(64)
}))).middleware([authMiddleware]).handler(lookupItem_createServerFn_handler, async ({ data, context }) => {
	const sql = await getSql();
	await requireMember(sql, data.warehouseId, context.userId);
	const code = normalizeItemCode(data.code);
	const rows = await sql`
      select id, warehouse_id, code, name, unit, qty, min_qty, location, updated_at
      from items
      where warehouse_id = ${data.warehouseId} and code = ${code}
    `;
	return { item: rows[0] ? mapItem(rows[0]) : null };
});
var itemInput = object({
	warehouseId: idSchema,
	id: string().trim().min(8).max(80).nullable(),
	code: string().trim().min(1, "Inserisci il codice.").max(64),
	name: string().trim().min(1, "Inserisci il nome.").max(80),
	unit: string().trim().min(1, "Indica l'unità.").max(16),
	qty: number().finite().min(0, "La giacenza non può essere negativa.").max(1e9),
	minQty: number().finite().min(0, "La soglia non può essere negativa.").max(1e9),
	location: string().trim().max(80)
});
var saveItem_createServerFn_handler = createServerRpc({
	id: "5a4055694e609ba9b7be325e8ca81e43b95e0ec7d4162b1fb55e5daea6cc46a3",
	name: "saveItem",
	filename: "src/lib/stiva/api.ts"
}, (opts) => saveItem.__executeServer(opts));
var saveItem = createServerFn({ method: "POST" }).validator(parse(itemInput)).middleware([authMiddleware]).handler(saveItem_createServerFn_handler, async ({ data, context }) => {
	const sql = await getSql();
	await requireMember(sql, data.warehouseId, context.userId);
	const who = await actor(sql, context.userId);
	const code = normalizeItemCode(data.code);
	if (!code) throw new Error("Inserisci il codice.");
	const qty = round3(data.qty);
	const minQty = round3(data.minQty);
	const name = data.name.trim();
	const unit = data.unit.trim();
	const location = data.location.trim();
	if (!data.id) {
		const id = crypto.randomUUID();
		try {
			await sql`
          insert into items (id, warehouse_id, code, name, unit, qty, min_qty, location)
          values (${id}, ${data.warehouseId}, ${code}, ${name}, ${unit}, ${qty}, ${minQty}, ${location})
        `;
		} catch (error) {
			if (isUnique(error)) throw new Error("Esiste già un articolo con questo codice.");
			throw error;
		}
		await sql`
        insert into movements (
          id, warehouse_id, item_id, item_code, item_name, user_id, actor_name,
          kind, qty, qty_before, qty_after, note
        ) values (
          ${crypto.randomUUID()}, ${data.warehouseId}, ${id}, ${code}, ${name},
          ${context.userId}, ${who.name}, 'rettifica', ${qty}, ${0}, ${qty}, 'Giacenza iniziale'
        )
      `;
		const item = await loadItem(sql, data.warehouseId, id);
		if (!item) throw new Error("Articolo non salvato.");
		return {
			item,
			threshold_hit: false,
			alert: null,
			mailto: null
		};
	}
	const prev = await loadItem(sql, data.warehouseId, data.id);
	if (!prev) throw new Error("Articolo non trovato.");
	try {
		await sql`
        update items
        set code = ${code},
            name = ${name},
            unit = ${unit},
            qty = ${qty},
            min_qty = ${minQty},
            location = ${location},
            updated_at = now()
        where id = ${data.id} and warehouse_id = ${data.warehouseId}
      `;
	} catch (error) {
		if (isUnique(error)) throw new Error("Esiste già un articolo con questo codice.");
		throw error;
	}
	if (prev.qty !== qty) await sql`
        insert into movements (
          id, warehouse_id, item_id, item_code, item_name, user_id, actor_name,
          kind, qty, qty_before, qty_after, note
        ) values (
          ${crypto.randomUUID()}, ${data.warehouseId}, ${data.id}, ${code}, ${name},
          ${context.userId}, ${who.name}, 'rettifica', ${qty}, ${prev.qty}, ${qty}, 'Correzione giacenza'
        )
      `;
	const item = await loadItem(sql, data.warehouseId, data.id);
	if (!item) throw new Error("Articolo non trovato.");
	return {
		item,
		...await raiseAlert(sql, {
			warehouseId: data.warehouseId,
			item,
			qtyBefore: prev.qty,
			minBefore: prev.min_qty
		})
	};
});
var deleteItem_createServerFn_handler = createServerRpc({
	id: "73a77904415a580b55167c72f2822bb4f96ae11655220d1734c62e165a621682",
	name: "deleteItem",
	filename: "src/lib/stiva/api.ts"
}, (opts) => deleteItem.__executeServer(opts));
var deleteItem = createServerFn({ method: "POST" }).validator(parse(object({
	warehouseId: idSchema,
	itemId: idSchema
}))).middleware([authMiddleware]).handler(deleteItem_createServerFn_handler, async ({ data, context }) => {
	const sql = await getSql();
	await requireMember(sql, data.warehouseId, context.userId);
	await sql`
      delete from alerts
      where warehouse_id = ${data.warehouseId} and item_id = ${data.itemId}
    `;
	if (!(await sql`
      delete from items
      where id = ${data.itemId} and warehouse_id = ${data.warehouseId}
      returning id
    `)[0]) throw new Error("Articolo non trovato.");
	return { ok: true };
});
var recordMove_createServerFn_handler = createServerRpc({
	id: "487ac2a7917c0b03f5e6e97a5e0b3399d0baa327f6aaf2dc7e5a7143a67e016d",
	name: "recordMove",
	filename: "src/lib/stiva/api.ts"
}, (opts) => recordMove.__executeServer(opts));
var recordMove = createServerFn({ method: "POST" }).validator(parse(object({
	warehouseId: idSchema,
	itemId: idSchema,
	kind: _enum(["prelievo", "carico"]),
	qty: number().finite().gt(0, "Inserisci una quantità maggiore di zero.").max(1e9),
	note: string().trim().max(200)
}))).middleware([authMiddleware]).handler(recordMove_createServerFn_handler, async ({ data, context }) => {
	const sql = await getSql();
	await requireMember(sql, data.warehouseId, context.userId);
	const who = await actor(sql, context.userId);
	const prev = await loadItem(sql, data.warehouseId, data.itemId);
	if (!prev) throw new Error("Articolo non trovato.");
	const delta = round3(data.qty);
	if (data.kind === "prelievo" && delta > prev.qty + 1e-9) throw new Error(`Giacenza insufficiente: disponibili ${formatQty(prev.qty)} ${prev.unit}.`);
	const nextQty = data.kind === "prelievo" ? round3(prev.qty - delta) : round3(prev.qty + delta);
	await sql`
      update items
      set qty = ${nextQty}, updated_at = now()
      where id = ${prev.id} and warehouse_id = ${data.warehouseId}
    `;
	await sql`
      insert into movements (
        id, warehouse_id, item_id, item_code, item_name, user_id, actor_name,
        kind, qty, qty_before, qty_after, note
      ) values (
        ${crypto.randomUUID()},
        ${data.warehouseId},
        ${prev.id},
        ${prev.code},
        ${prev.name},
        ${context.userId},
        ${who.name},
        ${data.kind},
        ${delta},
        ${prev.qty},
        ${nextQty},
        ${data.note}
      )
    `;
	const item = await loadItem(sql, data.warehouseId, prev.id);
	if (!item) throw new Error("Articolo non trovato.");
	return {
		item,
		...await raiseAlert(sql, {
			warehouseId: data.warehouseId,
			item,
			qtyBefore: prev.qty,
			minBefore: prev.min_qty
		})
	};
});
var listMovements_createServerFn_handler = createServerRpc({
	id: "00266f1e36e6de7112365a85e93a3bfe242ccf722ee67b161179f3e143134ec8",
	name: "listMovements",
	filename: "src/lib/stiva/api.ts"
}, (opts) => listMovements.__executeServer(opts));
var listMovements = createServerFn({ method: "POST" }).validator(parse(object({
	warehouseId: idSchema,
	itemId: string().trim().max(80).nullable()
}))).middleware([authMiddleware]).handler(listMovements_createServerFn_handler, async ({ data, context }) => {
	const sql = await getSql();
	await requireMember(sql, data.warehouseId, context.userId);
	return (data.itemId ? await sql`
          select id, item_id, item_code, item_name, actor_name, kind, qty, qty_before, qty_after, note, created_at
          from movements
          where warehouse_id = ${data.warehouseId} and item_id = ${data.itemId}
          order by created_at desc
          limit 40
        ` : await sql`
          select id, item_id, item_code, item_name, actor_name, kind, qty, qty_before, qty_after, note, created_at
          from movements
          where warehouse_id = ${data.warehouseId}
          order by created_at desc
          limit 60
        `).map((row) => ({
		...row,
		qty: num(row.qty),
		qty_before: num(row.qty_before),
		qty_after: num(row.qty_after),
		note: row.note ?? "",
		created_at: iso(row.created_at)
	}));
});
var listAlerts_createServerFn_handler = createServerRpc({
	id: "bc03e088f3f7a8d5bbdac3a3513b105e3aac34be30a860b8eb0adc4f4e7141ee",
	name: "listAlerts",
	filename: "src/lib/stiva/api.ts"
}, (opts) => listAlerts.__executeServer(opts));
var listAlerts = createServerFn({ method: "POST" }).validator(parse(object({ warehouseId: idSchema }))).middleware([authMiddleware]).handler(listAlerts_createServerFn_handler, async ({ data, context }) => {
	const sql = await getSql();
	await requireMember(sql, data.warehouseId, context.userId);
	return (await sql`
      select a.id, a.item_id, a.item_code, a.item_name, a.unit,
             a.qty_after, a.min_qty, a.message, a.recipients, a.created_at
      from alerts a
      join alert_receipts r on r.alert_id = a.id and r.user_id = ${context.userId}
      where a.warehouse_id = ${data.warehouseId} and r.acked_at is null
      order by a.created_at desc
      limit 30
    `).map((row) => ({
		...row,
		qty_after: num(row.qty_after),
		min_qty: num(row.min_qty),
		recipients: row.recipients ?? "",
		created_at: iso(row.created_at)
	}));
});
var ackAlerts_createServerFn_handler = createServerRpc({
	id: "7e20b3eec38fd8ca91038f6a9d8cda081fdafe160d0cdd9a3b0a6982d6507911",
	name: "ackAlerts",
	filename: "src/lib/stiva/api.ts"
}, (opts) => ackAlerts.__executeServer(opts));
var ackAlerts = createServerFn({ method: "POST" }).validator(parse(object({ warehouseId: idSchema }))).middleware([authMiddleware]).handler(ackAlerts_createServerFn_handler, async ({ data, context }) => {
	const sql = await getSql();
	await requireMember(sql, data.warehouseId, context.userId);
	await sql`
      update alert_receipts r
      set acked_at = now()
      from alerts a
      where r.alert_id = a.id
        and a.warehouse_id = ${data.warehouseId}
        and r.user_id = ${context.userId}
        and r.acked_at is null
    `;
	return { ok: true };
});
//#endregion
export { ackAlerts_createServerFn_handler, createWarehouse_createServerFn_handler, deleteItem_createServerFn_handler, deleteWarehouse_createServerFn_handler, joinWarehouse_createServerFn_handler, leaveWarehouse_createServerFn_handler, listAlerts_createServerFn_handler, listItems_createServerFn_handler, listMembers_createServerFn_handler, listMovements_createServerFn_handler, listWarehouses_createServerFn_handler, lookupItem_createServerFn_handler, recordMove_createServerFn_handler, saveItem_createServerFn_handler, updateNotifyEmail_createServerFn_handler };
