import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as DialogPortal, i as DialogOverlay, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { _ as parseQty, a as buildMailto, c as formatQty, d as isLow, l as formatQtyInput, n as UNITS, o as extractCode, p as markAlertsSeen, r as WAREHOUSE_KEY, s as formatJoin, t as AUTO_MAIL_KEY, u as formatWhen, v as readSeen } from "./format-D4Bv_-7v.mjs";
import { a as hasGateSessionMarker } from "./server-_FnbRQv7.mjs";
import { _ as Bell, a as Share2, c as Pencil, d as MapPin, f as Mail, g as Check, h as ChevronLeft, i as Trash2, l as Package, m as Copy, n as Users, o as ScanLine, p as Keyboard, s as Plus, t as X, u as Minus } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { i as signOut } from "./client-1vAx-gM_.mjs";
import { i as useCurrentUserState, n as LoginPanel, r as useCurrentUser, t as BootScreen } from "./login-panel-J-UwXrSk.mjs";
import { a as joinWarehouse, c as listItems, d as listWarehouses, f as lookupItem, h as updateNotifyEmail, i as deleteWarehouse, l as listMembers, m as saveItem, n as createWarehouse, o as leaveWarehouse, p as recordMove, r as deleteItem, s as listAlerts, t as ackAlerts, u as listMovements } from "./api-C9GurCZt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CnXX96hi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function openMail(href) {
	const link = document.createElement("a");
	link.href = href;
	link.rel = "noopener";
	link.style.display = "none";
	document.body.appendChild(link);
	link.click();
	link.remove();
}
function pingNotification(title, body) {
	if (typeof Notification === "undefined" || Notification.permission !== "granted") return;
	try {
		new Notification(title, { body });
	} catch {}
}
function vibrateAlert() {
	try {
		navigator.vibrate?.([
			28,
			36,
			28
		]);
	} catch {}
}
async function requestScreenNotifications() {
	if (typeof Notification === "undefined") return "unsupported";
	return Notification.requestPermission();
}
function Scanner({ onCode, onClose }) {
	const videoRef = (0, import_react.useRef)(null);
	const [manual, setManual] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		const video = videoRef.current;
		if (!video) return;
		let cancel = false;
		let stream = null;
		let frame = 0;
		let controls = null;
		const stopTracks = () => {
			stream?.getTracks().forEach((track) => track.stop());
			stream = null;
		};
		const finish = (raw) => {
			const code = extractCode(raw);
			if (!code || cancel) return;
			cancel = true;
			cancelAnimationFrame(frame);
			controls?.stop();
			stopTracks();
			onCode(code);
		};
		const fail = (caught) => {
			if (cancel) return;
			if ((caught instanceof DOMException ? caught.name : "") === "NotAllowedError") setError("Permesso fotocamera negato. Inserisci il codice a mano.");
			else setError("Fotocamera non disponibile. Inserisci il codice a mano.");
			setBusy(false);
		};
		(async () => {
			const DetectorCtor = window.BarcodeDetector;
			if (DetectorCtor && navigator.mediaDevices?.getUserMedia) try {
				stream = await navigator.mediaDevices.getUserMedia({
					audio: false,
					video: { facingMode: { ideal: "environment" } }
				});
				if (cancel) {
					stopTracks();
					return;
				}
				video.srcObject = stream;
				await video.play();
				setBusy(false);
				const detector = new DetectorCtor({ formats: [
					"qr_code",
					"ean_13",
					"ean_8",
					"code_128",
					"code_39",
					"upc_a",
					"upc_e",
					"itf"
				] });
				const tick = async () => {
					if (cancel) return;
					try {
						const raw = (await detector.detect(video)).find((row) => row.rawValue)?.rawValue;
						if (raw) {
							finish(raw);
							return;
						}
					} catch {}
					frame = requestAnimationFrame(() => void tick());
				};
				frame = requestAnimationFrame(() => void tick());
				return;
			} catch (caught) {
				stopTracks();
				fail(caught);
				return;
			}
			try {
				const { BrowserMultiFormatReader } = await import("../_libs/@zxing/browser+[...].mjs").then((n) => n.t);
				if (cancel) return;
				controls = await new BrowserMultiFormatReader().decodeFromVideoDevice(void 0, video, (result) => {
					if (result) finish(result.getText());
				});
				if (cancel) controls.stop();
				else setBusy(false);
			} catch (caught) {
				fail(caught);
			}
		})();
		return () => {
			cancel = true;
			cancelAnimationFrame(frame);
			controls?.stop();
			stopTracks();
		};
	}, [onCode]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "fixed inset-0 z-40 flex flex-col bg-ink text-accent-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sheet-top border-transparent bg-ink text-accent-fg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow finder-kicker",
					children: "Lettura"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "wordmark",
					children: "Inquadra il codice"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "icon-btn finder-close",
					onClick: onClose,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
						className: "size-5",
						"aria-hidden": "true"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: "Chiudi"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "finder",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
						ref: videoRef,
						muted: true,
						playsInline: true,
						autoPlay: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "finder-frame" }),
					busy && !error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "absolute inset-x-0 bottom-4 text-center text-sm",
						children: "Avvio fotocamera…"
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "stack bg-bg p-4 text-ink",
				onSubmit: (event) => {
					event.preventDefault();
					const code = extractCode(manual);
					if (!code) return;
					onCode(code);
				},
				children: [
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "note-danger note",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Keyboard, {
								className: "size-4",
								"aria-hidden": "true"
							}), "Oppure scrivi il codice"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "scan-code",
							value: manual,
							autoCapitalize: "characters",
							autoCorrect: "off",
							placeholder: "Es. VITE-M8",
							onChange: (event) => setManual(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "btn btn-primary w-full",
						children: "Seleziona articolo"
					})
				]
			})
		]
	});
}
function messageOf(error) {
	if (error instanceof Error) return error.message === "Unauthorized" ? "Sessione scaduta. Entra di nuovo." : error.message;
	return "Qualcosa non ha funzionato.";
}
function StatusPill({ item }) {
	if (item.qty <= 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "pill pill-danger",
		children: "Esaurito"
	});
	if (isLow(item.qty, item.min_qty)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "pill pill-warn",
		children: "Sotto soglia"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "pill pill-ok",
		children: "Ok"
	});
}
function QrImage({ code }) {
	const [src, setSrc] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		import("../_libs/qrcode.mjs").then((n) => /* @__PURE__ */ __toESM(n.t())).then((mod) => mod.toDataURL(code, {
			margin: 1,
			width: 320,
			color: {
				dark: "#1c1915",
				light: "#fffcf7"
			}
		})).then((url) => {
			if (live) setSrc(url);
		}).catch(() => {
			if (live) setSrc(null);
		});
		return () => {
			live = false;
		};
	}, [code]);
	if (!src) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid h-52 w-52 place-items-center bg-chip text-sm text-muted",
		children: "QR"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		className: "h-52 w-52",
		src,
		width: 208,
		height: 208,
		alt: `Codice QR ${code}`
	});
}
function StivaApp() {
	const qc = useQueryClient();
	const user = useCurrentUser();
	const [ready, setReady] = (0, import_react.useState)(false);
	const [warehouseId, setWarehouseId] = (0, import_react.useState)(null);
	const [tab, setTab] = (0, import_react.useState)("stock");
	const [overlay, setOverlay] = (0, import_react.useState)(null);
	const [query, setQuery] = (0, import_react.useState)("");
	const [onlyLow, setOnlyLow] = (0, import_react.useState)(false);
	const [toast, setToast] = (0, import_react.useState)(null);
	const [forced, setForced] = (0, import_react.useState)([]);
	const [defer, setDefer] = (0, import_react.useState)(false);
	const [autoMail, setAutoMail] = (0, import_react.useState)(true);
	const [perm, setPerm] = (0, import_react.useState)("default");
	const picked = (0, import_react.useRef)(false);
	const booted = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		setWarehouseId(localStorage.getItem(WAREHOUSE_KEY));
		setAutoMail(localStorage.getItem(AUTO_MAIL_KEY) !== "0");
		setPerm(typeof Notification === "undefined" ? "unsupported" : Notification.permission);
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!toast) return;
		const timer = window.setTimeout(() => setToast(null), 2800);
		return () => window.clearTimeout(timer);
	}, [toast]);
	const warehouses = useQuery({
		queryKey: ["warehouses"],
		queryFn: () => listWarehouses()
	});
	const chooseWarehouse = (0, import_react.useCallback)((id) => {
		picked.current = true;
		setWarehouseId(id);
		setOverlay(null);
		setTab("stock");
		setQuery("");
		if (id) localStorage.setItem(WAREHOUSE_KEY, id);
		else localStorage.removeItem(WAREHOUSE_KEY);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready || !warehouses.data || booted.current) return;
		booted.current = true;
		if (warehouseId && warehouses.data.some((row) => row.id === warehouseId)) return;
		if (warehouses.data[0]) chooseWarehouse(warehouses.data[0].id);
	}, [
		chooseWarehouse,
		ready,
		warehouseId,
		warehouses.data
	]);
	(0, import_react.useEffect)(() => {
		if (!ready || !warehouses.data || !warehouseId || !booted.current) return;
		if (warehouses.data.some((row) => row.id === warehouseId)) return;
		chooseWarehouse(warehouses.data[0]?.id ?? null);
	}, [
		chooseWarehouse,
		ready,
		warehouseId,
		warehouses.data
	]);
	const remember = (0, import_react.useCallback)((row) => {
		qc.setQueryData(["warehouses"], (prev) => {
			const list = prev ?? [];
			if (list.some((item) => item.id === row.id)) return list;
			return [row, ...list];
		});
		chooseWarehouse(row.id);
	}, [chooseWarehouse, qc]);
	const warehouse = warehouses.data?.find((row) => row.id === warehouseId) ?? null;
	const itemsQuery = useQuery({
		queryKey: ["items", warehouseId],
		enabled: Boolean(warehouseId),
		queryFn: () => listItems({ data: { warehouseId } }),
		refetchInterval: 8e3
	});
	const alertsQuery = useQuery({
		queryKey: ["alerts", warehouseId],
		enabled: Boolean(warehouseId),
		queryFn: () => listAlerts({ data: { warehouseId } }),
		refetchInterval: 8e3
	});
	const moveItemId = overlay?.type === "detail" ? overlay.itemId : overlay?.type === "log" ? overlay.itemId : void 0;
	const movesQuery = useQuery({
		queryKey: [
			"moves",
			warehouseId,
			moveItemId ?? "all"
		],
		enabled: Boolean(warehouseId) && moveItemId !== void 0,
		queryFn: () => listMovements({ data: {
			warehouseId,
			itemId: moveItemId ?? null
		} })
	});
	const membersQuery = useQuery({
		queryKey: ["members", warehouseId],
		enabled: Boolean(warehouseId) && (tab === "team" || overlay?.type === "detail"),
		queryFn: () => listMembers({ data: { warehouseId } })
	});
	const refresh = (0, import_react.useCallback)(async () => {
		await Promise.all([
			qc.invalidateQueries({ queryKey: ["items", warehouseId] }),
			qc.invalidateQueries({ queryKey: ["alerts", warehouseId] }),
			qc.invalidateQueries({ queryKey: ["moves", warehouseId] }),
			qc.invalidateQueries({ queryKey: ["warehouses"] }),
			qc.invalidateQueries({ queryKey: ["members", warehouseId] })
		]);
	}, [qc, warehouseId]);
	const forget = (0, import_react.useCallback)((id) => {
		const list = (qc.getQueryData(["warehouses"]) ?? []).filter((row) => row.id !== id);
		qc.setQueryData(["warehouses"], list);
		chooseWarehouse(list[0]?.id ?? null);
		refresh();
	}, [
		chooseWarehouse,
		qc,
		refresh
	]);
	const publish = (0, import_react.useCallback)((result, quiet) => {
		if (result.threshold_hit && result.alert) {
			setForced((prev) => [result.alert, ...prev.filter((row) => row.id !== result.alert.id)]);
			setDefer(false);
			markAlertsSeen([result.alert.id]);
			vibrateAlert();
			pingNotification(`Sotto soglia · ${result.alert.item_code}`, result.alert.message);
			if (autoMail && result.mailto) openMail(result.mailto);
			setToast("Soglia minima raggiunta");
		} else setToast(quiet);
		refresh();
	}, [autoMail, refresh]);
	(0, import_react.useEffect)(() => {
		const incoming = alertsQuery.data;
		if (!incoming?.length) return;
		const seen = readSeen();
		const fresh = incoming.filter((alert) => !seen.has(alert.id));
		if (!fresh.length) return;
		markAlertsSeen(fresh.map((alert) => alert.id));
		setDefer(false);
		pingNotification(fresh.length === 1 ? `Sotto soglia · ${fresh[0].item_code}` : `${fresh.length} articoli sotto soglia`, fresh.map((alert) => alert.message).join("\n"));
	}, [alertsQuery.data]);
	const alerts = (0, import_react.useMemo)(() => {
		const merged = [...forced, ...alertsQuery.data ?? []];
		return merged.filter((alert, index) => merged.findIndex((row) => row.id === alert.id) === index);
	}, [alertsQuery.data, forced]);
	const items = itemsQuery.data ?? [];
	const filtered = items.filter((item) => {
		if (onlyLow && !isLow(item.qty, item.min_qty)) return false;
		return `${item.code} ${item.name} ${item.location}`.toLowerCase().includes(query.trim().toLowerCase());
	});
	const lowCount = items.filter((item) => isLow(item.qty, item.min_qty)).length;
	const showAlert = alerts.length > 0 && !defer && overlay?.type !== "scan";
	const mailHref = buildMailto(alerts.flatMap((alert) => alert.recipients.split(",")), alerts.map((alert) => ({
		code: alert.item_code,
		name: alert.item_name,
		qty: alert.qty_after,
		min: alert.min_qty,
		unit: alert.unit
	})));
	const onScan = (0, import_react.useCallback)(async (code) => {
		if (!warehouseId) return;
		setOverlay(null);
		try {
			const found = await lookupItem({ data: {
				warehouseId,
				code
			} });
			if (found.item) setOverlay({
				type: "move",
				itemId: found.item.id,
				kind: "prelievo"
			});
			else {
				setToast(`Nessun articolo ${code}. Creane uno.`);
				setOverlay({
					type: "edit",
					itemId: null,
					presetCode: code
				});
			}
		} catch (error) {
			setToast(messageOf(error));
		}
	}, [warehouseId]);
	const ack = useMutation({
		mutationFn: () => ackAlerts({ data: { warehouseId } }),
		onSuccess: () => {
			setForced([]);
			refresh();
		}
	});
	if (!ready || warehouses.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "eyebrow",
			children: "Magazzino"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "wordmark text-3xl",
			children: "Stiva"
		})] })
	});
	if (warehouses.isError) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-screen w-full max-w-xl flex-col justify-center gap-4 px-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-semibold tracking-tight",
				children: "Stiva"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "note note-danger",
				role: "alert",
				children: messageOf(warehouses.error)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-primary",
				onClick: () => void warehouses.refetch(),
				children: "Riprova"
			})
		]
	});
	const liveItem = (id) => items.find((item) => item.id === id) ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-frame",
		children: [
			overlay?.type === "scan" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scanner, {
				onCode: (code) => void onScan(code),
				onClose: () => setOverlay(null)
			}) : null,
			overlay?.type === "edit" && warehouseId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemEditor, {
				warehouseId,
				item: overlay.itemId ? liveItem(overlay.itemId) : null,
				presetCode: overlay.presetCode,
				onClose: () => setOverlay(null),
				onSaved: (result) => {
					setOverlay(null);
					publish(result, "Articolo salvato");
				}
			}) : null,
			overlay?.type === "move" && warehouseId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MovePad, {
				warehouseId,
				item: liveItem(overlay.itemId),
				initialKind: overlay.kind,
				onClose: () => setOverlay({
					type: "detail",
					itemId: overlay.itemId
				}),
				onSaved: (result, kind) => {
					setOverlay({
						type: "detail",
						itemId: result.item.id
					});
					publish(result, kind === "prelievo" ? "Prelievo registrato" : "Carico registrato");
				}
			}) : null,
			overlay?.type === "detail" && warehouse ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemDetail, {
				item: liveItem(overlay.itemId),
				moves: movesQuery.data ?? [],
				onBack: () => setOverlay(null),
				onMove: (kind) => setOverlay({
					type: "move",
					itemId: overlay.itemId,
					kind
				}),
				onEdit: () => setOverlay({
					type: "edit",
					itemId: overlay.itemId
				}),
				onDeleted: () => {
					setOverlay(null);
					setToast("Articolo eliminato");
					refresh();
				},
				warehouseId: warehouse.id
			}) : null,
			overlay?.type === "log" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogView, {
				moves: movesQuery.data ?? [],
				loading: movesQuery.isLoading,
				onBack: () => setOverlay(null)
			}) : null,
			!overlay ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "topbar",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow",
							children: "Stiva"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "truncate text-lg font-semibold tracking-tight",
							children: warehouse ? warehouse.name : "Magazzino condiviso"
						})]
					}), warehouse ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "icon-btn bell",
						"aria-label": alerts.length ? `${alerts.length} avvisi` : "Avvisi",
						onClick: () => setDefer(false),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, {
							className: "size-5",
							"aria-hidden": "true"
						}), alerts.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "bell-count",
							children: alerts.length
						}) : null]
					}) : null]
				}),
				!warehouse ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeGate, {
					email: user?.primaryEmail ?? "",
					onReady: remember
				}) : tab === "stock" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "pad stack",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "stat",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: items.length }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "meta",
									children: "Articoli"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "stat",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: lowCount }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "meta",
									children: "Sotto soglia"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "field min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "sr-only",
									children: "Cerca"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: query,
									placeholder: "Cerca codice o nome",
									onChange: (event) => setQuery(event.target.value)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-ghost",
								onClick: () => setOverlay({
									type: "log",
									itemId: null
								}),
								children: "Registro"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "chips",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "chip",
								"aria-pressed": !onlyLow,
								onClick: () => setOnlyLow(false),
								children: "Tutti"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "chip",
								"aria-pressed": onlyLow,
								onClick: () => setOnlyLow(true),
								children: "Sotto soglia"
							})]
						}),
						itemsQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "stack",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "skeleton" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "skeleton" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "skeleton" })
							]
						}) : itemsQuery.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "note note-danger",
							role: "alert",
							children: messageOf(itemsQuery.error)
						}) : filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "card stack",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-lg font-semibold",
									children: items.length === 0 ? "Nessun articolo" : "Nessun risultato"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "lede",
									children: items.length === 0 ? "Aggiungi un codice con la giacenza e la soglia minima. Il QR servirà a prelevare dal telefono." : "Prova un altro codice o togli il filtro."
								}),
								items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-primary",
									onClick: () => setOverlay({
										type: "edit",
										itemId: null
									}),
									children: "Nuovo articolo"
								}) : null
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "stack",
							children: filtered.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "item-row",
								onClick: () => setOverlay({
									type: "detail",
									itemId: item.id
								}),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "code text-sm",
												children: item.code
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { item })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-1 block truncate font-medium",
											children: item.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "meta",
											children: [
												"Soglia ",
												formatQty(item.min_qty),
												" ",
												item.unit,
												item.location ? ` · ${item.location}` : ""
											]
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-right",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "qty text-2xl",
										children: formatQty(item.qty)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "meta block",
										children: item.unit
									})]
								})]
							}, item.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "btn btn-ghost w-full",
							onClick: () => setOverlay({
								type: "edit",
								itemId: null
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
								className: "size-4",
								"aria-hidden": "true"
							}), "Nuovo articolo"]
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamPanel, {
					warehouse,
					members: membersQuery.data ?? [],
					autoMail,
					perm,
					onAutoMail: (value) => {
						setAutoMail(value);
						localStorage.setItem(AUTO_MAIL_KEY, value ? "1" : "0");
					},
					onPerm: setPerm,
					onSwitch: chooseWarehouse,
					warehouses: warehouses.data ?? [],
					onLeft: () => forget(warehouse.id),
					onToast: setToast
				}),
				warehouse ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "dock no-print",
					"aria-label": "Sezioni",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"aria-current": tab === "stock" ? "page" : void 0,
							onClick: () => setTab("stock"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, {
								className: "size-5",
								"aria-hidden": "true"
							}), "Scorte"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "items-center",
							onClick: () => setOverlay({ type: "scan" }),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "scan-fab grid place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanLine, {
									className: "size-6",
									"aria-hidden": "true"
								})
							}), "Scansiona"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"aria-current": tab === "team" ? "page" : void 0,
							onClick: () => setTab("team"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, {
								className: "size-5",
								"aria-hidden": "true"
							}), "Squadra"]
						})
					]
				}) : null
			] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: showAlert,
				onOpenChange: (open) => {
					if (!open) setDefer(true);
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "modal-overlay" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
					className: "modal-card",
					"aria-describedby": "alert-copy",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "modal-inner stack",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow",
								children: "Avviso"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
								className: "text-2xl font-semibold tracking-tight",
								children: "Soglia minima raggiunta"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
								id: "alert-copy",
								className: "lede",
								children: "La giacenza è scesa sotto il limite. L'avviso resta sullo schermo finché non lo confermi."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "stack",
								children: alerts.map((alert) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "card",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "code text-sm",
											children: alert.item_code
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-medium",
											children: alert.item_name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "qty mt-2 text-xl",
											children: [
												formatQty(alert.qty_after),
												" ",
												alert.unit
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "meta",
											children: [
												"Soglia ",
												formatQty(alert.min_qty),
												" ",
												alert.unit
											]
										})
									]
								}, alert.id))
							}),
							mailHref ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "btn btn-primary w-full",
								onClick: () => openMail(mailHref),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Invia mail al gruppo"]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "note",
								children: "Nessuna mail impostata. In Squadra aggiungi l'indirizzo: l'avviso a schermo è già attivo."
							}),
							mailHref ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "meta",
								children: [
									"Si apre la posta del telefono, già compilata",
									alerts[0]?.recipients ? ` per ${alerts[0].recipients}` : "",
									"."
								]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "btn btn-ghost w-full",
								disabled: ack.isPending || !warehouseId,
								onClick: () => ack.mutate(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
									className: "size-4",
									"aria-hidden": "true"
								}), ack.isPending ? "Salvo…" : "Ho visto"]
							})
						]
					})
				})] })
			}),
			toast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "toast",
				children: toast
			}) : null
		]
	});
}
function HomeGate({ email, onReady }) {
	const [mode, setMode] = (0, import_react.useState)("choose");
	const [name, setName] = (0, import_react.useState)("");
	const [notifyEmail, setNotifyEmail] = (0, import_react.useState)(email);
	const [code, setCode] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const create = useMutation({
		mutationFn: () => createWarehouse({ data: {
			name,
			notifyEmail
		} }),
		onSuccess: (warehouse) => onReady(warehouse),
		onError: (caught) => setError(messageOf(caught))
	});
	const join = useMutation({
		mutationFn: () => joinWarehouse({ data: { code } }),
		onSuccess: (warehouse) => onReady(warehouse),
		onError: (caught) => setError(messageOf(caught))
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "pad stack",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "lede",
				children: "Un codice per gli amici, le quantità sempre aggiornate. Chi preleva inquadra il QR e, sotto la soglia, il gruppo riceve l'avviso."
			}),
			mode === "choose" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-primary w-full",
				onClick: () => setMode("create"),
				children: "Crea un magazzino"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-ghost w-full",
				onClick: () => setMode("join"),
				children: "Entra con un codice"
			})] }) : null,
			mode === "create" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "card stack",
				onSubmit: (event) => {
					event.preventDefault();
					setError(null);
					create.mutate();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "Nuovo magazzino"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Nome" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "wh-name",
							required: true,
							value: name,
							placeholder: "Officina, furgone, cantiere",
							onChange: (event) => setName(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Mail per gli avvisi" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "email",
							value: notifyEmail,
							placeholder: "Anche una casella condivisa",
							onChange: (event) => setNotifyEmail(event.target.value)
						})]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "note note-danger",
						role: "alert",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn btn-primary",
						type: "submit",
						disabled: create.isPending,
						children: create.isPending ? "Creo…" : "Crea e condividi"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost",
						onClick: () => setMode("choose"),
						children: "Indietro"
					})
				]
			}) : null,
			mode === "join" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "card stack",
				onSubmit: (event) => {
					event.preventDefault();
					setError(null);
					join.mutate();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "Codice magazzino"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Codice" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "join-code",
							required: true,
							className: "code",
							autoCapitalize: "characters",
							value: code,
							placeholder: "ABC-123",
							onChange: (event) => setCode(event.target.value)
						})]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "note note-danger",
						role: "alert",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn btn-primary",
						type: "submit",
						disabled: join.isPending,
						children: join.isPending ? "Entro…" : "Entra"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost",
						onClick: () => setMode("choose"),
						children: "Indietro"
					})
				]
			}) : null
		]
	});
}
function ItemEditor({ warehouseId, item, presetCode, onClose, onSaved }) {
	const [code, setCode] = (0, import_react.useState)(item?.code ?? presetCode ?? "");
	const [name, setName] = (0, import_react.useState)(item?.name ?? "");
	const [unit, setUnit] = (0, import_react.useState)(item?.unit ?? "pz");
	const [qty, setQty] = (0, import_react.useState)(item ? formatQtyInput(item.qty) : "");
	const [minQty, setMinQty] = (0, import_react.useState)(item ? formatQtyInput(item.min_qty) : "");
	const [location, setLocation] = (0, import_react.useState)(item?.location ?? "");
	const [error, setError] = (0, import_react.useState)(null);
	const units = UNITS.includes(unit) ? UNITS : [unit, ...UNITS];
	const save = useMutation({
		mutationFn: () => {
			const parsedQty = parseQty(qty);
			const parsedMin = parseQty(minQty || "0");
			if (parsedQty === null || parsedMin === null) throw new Error("Controlla giacenza e soglia.");
			return saveItem({ data: {
				warehouseId,
				id: item?.id ?? null,
				code,
				name,
				unit,
				qty: parsedQty,
				minQty: parsedMin,
				location
			} });
		},
		onSuccess: onSaved,
		onError: (caught) => setError(messageOf(caught))
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "stack",
		onSubmit: (event) => {
			event.preventDefault();
			setError(null);
			save.mutate();
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "sheet-top",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "icon-btn",
				onClick: onClose,
				"aria-label": "Indietro",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "min-w-0 flex-1 text-lg font-semibold",
				children: item ? "Modifica articolo" : "Nuovo articolo"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pad stack",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Codice" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "item-code",
						required: true,
						className: "code",
						autoCapitalize: "characters",
						value: code,
						placeholder: "Quello sul QR o sul codice a barre",
						onChange: (event) => setCode(event.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Nome" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "item-name",
						required: true,
						value: name,
						onChange: (event) => setName(event.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Giacenza" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "item-qty",
							inputMode: "decimal",
							required: true,
							value: qty,
							onChange: (event) => setQty(event.target.value)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Soglia minima" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "item-min",
							inputMode: "decimal",
							required: true,
							value: minQty,
							placeholder: "0",
							onChange: (event) => setMinQty(event.target.value)
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Unità" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: unit,
						onChange: (event) => setUnit(event.target.value),
						children: units.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: option,
							children: option
						}, option))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Ubicazione" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: location,
						placeholder: "Scaffale, furgone, cantiere",
						onChange: (event) => setLocation(event.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "meta",
					children: "Sotto la soglia, Stiva avvisa a schermo e prepara la mail per la squadra."
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "note note-danger",
					role: "alert",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn btn-primary w-full",
					type: "submit",
					disabled: save.isPending,
					children: save.isPending ? "Salvo…" : "Salva articolo"
				})
			]
		})]
	});
}
function MovePad({ warehouseId, item, initialKind, onClose, onSaved }) {
	const [kind, setKind] = (0, import_react.useState)(initialKind);
	const [qty, setQty] = (0, import_react.useState)("1");
	const [note, setNote] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const parsed = parseQty(qty);
	const next = item && parsed !== null ? kind === "prelievo" ? item.qty - parsed : item.qty + parsed : null;
	const blocked = kind === "prelievo" && item && parsed !== null && parsed > item.qty;
	const move = useMutation({
		mutationFn: () => {
			if (!item) throw new Error("Articolo non trovato.");
			const amount = parseQty(qty);
			if (amount === null || amount <= 0) throw new Error("Inserisci una quantità maggiore di zero.");
			return recordMove({ data: {
				warehouseId,
				itemId: item.id,
				kind,
				qty: amount,
				note
			} });
		},
		onSuccess: (result) => onSaved(result, kind),
		onError: (caught) => setError(messageOf(caught))
	});
	if (!item) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "pad stack",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "btn btn-ghost",
			onClick: onClose,
			children: "Indietro"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "note",
			children: "Articolo non trovato."
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "stack",
		onSubmit: (event) => {
			event.preventDefault();
			setError(null);
			move.mutate();
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "sheet-top",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "icon-btn",
				onClick: onClose,
				"aria-label": "Indietro",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "code text-sm",
					children: item.code
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "truncate text-lg font-semibold",
					children: item.name
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pad stack",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "meta",
					children: [
						"Giacenza ",
						formatQty(item.qty),
						" ",
						item.unit,
						" · soglia ",
						formatQty(item.min_qty)
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "chips",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "chip",
						"aria-pressed": kind === "prelievo",
						onClick: () => setKind("prelievo"),
						children: "Prelievo"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "chip",
						"aria-pressed": kind === "carico",
						onClick: () => setKind("carico"),
						children: "Carico"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Quantità ", kind === "prelievo" ? "prelevata" : "caricata"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "move-qty",
						className: "qty text-3xl",
						inputMode: "decimal",
						value: qty,
						onChange: (event) => setQty(event.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "icon-btn",
							"aria-label": "Diminuisci",
							onClick: () => setQty(String(Math.max(0, (parsed ?? 0) - 1))),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-4" })
						}),
						[
							"1",
							"5",
							"10"
						].map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "chip",
							onClick: () => setQty(preset),
							children: preset
						}, preset)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "icon-btn",
							"aria-label": "Aumenta",
							onClick: () => setQty(String((parsed ?? 0) + 1)),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
						})
					]
				}),
				next !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: next <= item.min_qty ? "note note-warn" : "note",
					children: [
						"Dopo il movimento: ",
						formatQty(Math.max(0, next)),
						" ",
						item.unit,
						next <= item.min_qty ? " · scatta l'avviso di soglia" : ""
					]
				}) : null,
				blocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "note note-danger",
					children: "Quantità maggiore della giacenza."
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Nota" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: note,
						placeholder: "Commessa, cliente, motivo",
						onChange: (event) => setNote(event.target.value)
					})]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "note note-danger",
					role: "alert",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn btn-primary w-full",
					type: "submit",
					disabled: move.isPending || Boolean(blocked) || !parsed,
					children: move.isPending ? "Registro…" : kind === "prelievo" ? "Registra prelievo" : "Registra carico"
				})
			]
		})]
	});
}
function ItemDetail({ warehouseId, item, moves, onBack, onMove, onEdit, onDeleted }) {
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const remove = useMutation({
		mutationFn: () => deleteItem({ data: {
			warehouseId,
			itemId: item.id
		} }),
		onSuccess: onDeleted,
		onError: (caught) => setError(messageOf(caught))
	});
	if (!item) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "pad",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "btn btn-ghost",
			onClick: onBack,
			children: "Indietro"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "sheet-top no-print",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "icon-btn",
					onClick: onBack,
					"aria-label": "Indietro",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "min-w-0 flex-1 truncate text-lg font-semibold",
					children: item.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "icon-btn",
					onClick: onEdit,
					"aria-label": "Modifica",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pad stack items-center text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrImage, { code: item.code }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "code text-2xl",
					children: item.code
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "qty text-4xl",
					children: [
						formatQty(item.qty),
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-lg text-muted",
							children: item.unit
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { item }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "meta",
					children: [
						"Soglia minima ",
						formatQty(item.min_qty),
						" ",
						item.unit
					]
				}),
				item.location ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "meta inline-flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
						className: "size-4",
						"aria-hidden": "true"
					}), item.location]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "meta max-w-sm",
					children: "Stampa l'etichetta e applicala sull'articolo. In Stiva, Scansiona legge il QR e apre il prelievo."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pad stack no-print",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-primary w-full",
					onClick: () => onMove("prelievo"),
					children: "Registra prelievo"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-ghost w-full",
					onClick: () => onMove("carico"),
					children: "Registra carico"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-ghost w-full",
					onClick: () => window.print(),
					children: "Stampa etichetta"
				}),
				confirm ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-danger w-full",
					disabled: remove.isPending,
					onClick: () => remove.mutate(),
					children: remove.isPending ? "Elimino…" : "Conferma eliminazione"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "btn btn-ghost w-full",
					onClick: () => setConfirm(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
						className: "size-4",
						"aria-hidden": "true"
					}), "Elimina articolo"]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "note note-danger",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "pt-2 text-left text-base font-semibold",
					children: "Ultimi movimenti"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoveList, { moves })
			]
		})
	] });
}
function LogView({ moves, loading, onBack }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "sheet-top",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "icon-btn",
			onClick: onBack,
			"aria-label": "Indietro",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-lg font-semibold",
			children: "Registro"
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pad",
		children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "skeleton" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoveList, { moves })
	})] });
}
function MoveList({ moves }) {
	if (!moves.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "meta",
		children: "Nessun movimento."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "stack text-left",
		children: moves.map((move) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "card",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex items-baseline justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-medium",
						children: [
							move.kind === "prelievo" ? "Prelievo" : move.kind === "carico" ? "Carico" : "Rettifica",
							" · ",
							move.item_code
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "code text-sm",
						children: [move.kind === "carico" ? "+" : move.kind === "prelievo" ? "−" : "", formatQty(move.qty)]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "meta",
					children: [
						move.actor_name,
						" · ",
						formatQty(move.qty_before),
						" → ",
						formatQty(move.qty_after),
						" · ",
						formatWhen(move.created_at)
					]
				}),
				move.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm",
					children: move.note
				}) : null
			]
		}, move.id))
	});
}
function TeamPanel({ warehouse, members, warehouses, autoMail, perm, onAutoMail, onPerm, onSwitch, onLeft, onToast }) {
	const [mail, setMail] = (0, import_react.useState)(warehouse.notify_email);
	const [error, setError] = (0, import_react.useState)(null);
	const [danger, setDanger] = (0, import_react.useState)(null);
	const code = formatJoin(warehouse.join_code);
	const shareText = `Entra nel magazzino ${warehouse.name} su Stiva. Codice: ${code}`;
	const saveMail = useMutation({
		mutationFn: () => updateNotifyEmail({ data: {
			warehouseId: warehouse.id,
			notifyEmail: mail
		} }),
		onSuccess: () => onToast("Mail di avviso aggiornata"),
		onError: (caught) => setError(messageOf(caught))
	});
	const leave = useMutation({
		mutationFn: () => leaveWarehouse({ data: { warehouseId: warehouse.id } }),
		onSuccess: onLeft,
		onError: (caught) => setError(messageOf(caught))
	});
	const remove = useMutation({
		mutationFn: () => deleteWarehouse({ data: { warehouseId: warehouse.id } }),
		onSuccess: onLeft,
		onError: (caught) => setError(messageOf(caught))
	});
	async function copyCode() {
		try {
			await navigator.clipboard.writeText(code);
			onToast("Codice copiato");
		} catch {
			onToast(code);
		}
	}
	async function share() {
		try {
			if (navigator.share) await navigator.share({
				title: "Stiva",
				text: shareText
			});
			else await copyCode();
		} catch {}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "pad stack",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card stack",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "Codice per gli amici"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "code text-4xl",
						children: code
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "meta",
						children: "Chi ha un account Stiva può entrare e vedere le stesse quantità."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							id: "copy-code",
							type: "button",
							className: "btn btn-primary flex-1",
							onClick: () => void copyCode(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
								className: "size-4",
								"aria-hidden": "true"
							}), "Copia"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "btn btn-ghost flex-1",
							onClick: () => void share(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, {
								className: "size-4",
								"aria-hidden": "true"
							}), "Condividi"]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "card stack",
				onSubmit: (event) => {
					event.preventDefault();
					setError(null);
					saveMail.mutate();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "Mail di avviso"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "meta",
						children: "Oltre alle mail degli account in squadra. Quando scatta la soglia si apre il messaggio già scritto."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Indirizzo" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "email",
							value: mail,
							onChange: (event) => setMail(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn btn-ghost",
						type: "submit",
						disabled: saveMail.isPending,
						children: saveMail.isPending ? "Salvo…" : "Salva mail"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "chip w-fit",
						"aria-pressed": autoMail,
						onClick: () => onAutoMail(!autoMail),
						children: autoMail ? "Mail pronta in automatico" : "Mail solo su richiesta"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card stack",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "Notifica sul telefono"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "meta",
						children: "Aggiungi Stiva alla schermata Home. Con il permesso, l'avviso di soglia compare anche fuori dalla pagina."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "btn btn-ghost",
						onClick: () => {
							requestScreenNotifications().then((value) => {
								onPerm(value);
								onToast(value === "granted" ? "Notifiche attive" : "Permesso non concesso");
							});
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, {
							className: "size-4",
							"aria-hidden": "true"
						}), perm === "granted" ? "Notifiche attive" : perm === "unsupported" ? "Non disponibili qui" : "Attiva notifiche"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card stack",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold",
					children: "Squadra"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "stack",
					children: members.map((member) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-baseline justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-medium",
							children: member.display_name || "Operatore"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "meta",
							children: member.email || "Senza mail"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "meta",
							children: member.role === "owner" ? "Responsabile" : "In squadra"
						})]
					}, member.user_id))
				})]
			}),
			warehouses.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card stack",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold",
					children: "Altri magazzini"
				}), warehouses.filter((row) => row.id !== warehouse.id).map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-ghost w-full",
					onClick: () => onSwitch(row.id),
					children: row.name
				}, row.id))]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignOutRow, {}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "note note-danger",
				role: "alert",
				children: error
			}) : null,
			warehouse.role === "owner" ? danger === "delete" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-danger w-full",
				disabled: remove.isPending,
				onClick: () => remove.mutate(),
				children: remove.isPending ? "Elimino…" : "Conferma: elimina magazzino"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-ghost w-full",
				onClick: () => setDanger("delete"),
				children: "Elimina magazzino"
			}) : danger === "leave" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-danger w-full",
				disabled: leave.isPending,
				onClick: () => leave.mutate(),
				children: leave.isPending ? "Esco…" : "Conferma: esci dalla squadra"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-ghost w-full",
				onClick: () => setDanger("leave"),
				children: "Esci dalla squadra"
			})
		]
	});
}
function SignOutRow() {
	const user = useCurrentUser();
	const [pending, setPending] = (0, import_react.useState)(false);
	const gate = (0, import_react.useSyncExternalStore)(() => () => {}, hasGateSessionMarker, () => false);
	if (!user) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card stack",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium",
				children: user.displayName ?? "Account"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "meta",
				children: user.primaryEmail
			}),
			gate ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-ghost",
				disabled: pending,
				onClick: () => {
					setPending(true);
					signOut().catch(() => setPending(false));
				},
				children: pending ? "Uscita…" : "Esci dall'account"
			})
		]
	});
}
function Home() {
	const { user, isPending } = useCurrentUserState();
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, {});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoginPanel, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StivaApp, {});
}
//#endregion
export { Home as component };
