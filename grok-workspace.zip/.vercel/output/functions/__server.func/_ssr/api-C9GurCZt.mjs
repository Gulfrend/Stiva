import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { h as normalizeJoin, i as authMiddleware } from "./format-D4Bv_-7v.mjs";
import { D as _enum, F as object, P as number, R as string } from "../_libs/@better-auth/core+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-C9GurCZt.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function parse(schema) {
	return (input) => {
		const result = schema.safeParse(input);
		if (!result.success) throw new Error(result.error.issues[0]?.message ?? "Dati non validi.");
		return result.data;
	};
}
var idSchema = string().trim().min(8, "Identificativo non valido.").max(80);
var emailSchema = string().trim().max(120).refine((value) => value === "" || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value), "Mail non valida.");
var listWarehouses = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("3fa1b1382333e6252d52cfdbd94fd95ce6550b5f832b8c560e1c9325f7e55552"));
var createWarehouse = createServerFn({ method: "POST" }).validator(parse(object({
	name: string().trim().min(2, "Dai un nome al magazzino.").max(60),
	notifyEmail: emailSchema
}))).middleware([authMiddleware]).handler(createSsrRpc("09aa77ddb318b473e1941aa625db3ceb5672c64a5ded95e2a2ce6f52a803c892"));
var joinWarehouse = createServerFn({ method: "POST" }).validator((input) => {
	const data = parse(object({ code: string().trim().min(1, "Inserisci il codice.") }))(input);
	const code = normalizeJoin(data.code);
	if (code.length < 4) throw new Error("Codice non valido.");
	return { code };
}).middleware([authMiddleware]).handler(createSsrRpc("4d5a4c150f5a4c68287e5dfd5b7cef2bc1b57224c441fd3aedca2c0c05109c05"));
var updateNotifyEmail = createServerFn({ method: "POST" }).validator(parse(object({
	warehouseId: idSchema,
	notifyEmail: emailSchema
}))).middleware([authMiddleware]).handler(createSsrRpc("b40d7f4e7bc0568e17171d46eae987f4e9e64a195e596af592c6abe338e9fd9a"));
var listMembers = createServerFn({ method: "POST" }).validator(parse(object({ warehouseId: idSchema }))).middleware([authMiddleware]).handler(createSsrRpc("92d51b00c001828afc013347420ccd502b402669325c1ceb90855bb5f770f125"));
var leaveWarehouse = createServerFn({ method: "POST" }).validator(parse(object({ warehouseId: idSchema }))).middleware([authMiddleware]).handler(createSsrRpc("59a1cedf7a8c7d458363c5db348812b23f7bd1365dcda8e5223a2cd4b6cfac57"));
var deleteWarehouse = createServerFn({ method: "POST" }).validator(parse(object({ warehouseId: idSchema }))).middleware([authMiddleware]).handler(createSsrRpc("c5eb5c7f8c776c22b5e82592553dbb23062b34991eefccc969143bd37a2f58ba"));
var listItems = createServerFn({ method: "POST" }).validator(parse(object({ warehouseId: idSchema }))).middleware([authMiddleware]).handler(createSsrRpc("e97e2bc60500b0f46a4dbafb1826875671ce68763ccdeea22f9b74902fb102bc"));
var lookupItem = createServerFn({ method: "POST" }).validator(parse(object({
	warehouseId: idSchema,
	code: string().trim().min(1, "Inserisci il codice.").max(64)
}))).middleware([authMiddleware]).handler(createSsrRpc("5ea019172f022b2b124cf2ccc3392c6043a0bcc5a94a5af0e46b08cf3bcc66e3"));
var itemInput = object({
	warehouseId: idSchema,
	id: string().trim().min(8).max(80).nullable(),
	code: string().trim().min(1, "Inserisci il codice.").max(64),
	name: string().trim().min(1, "Inserisci il nome.").max(80),
	unit: string().trim().min(1, "Indica l'unità.").max(16),
	qty: number().finite().min(0, "La giacenza non può essere negativa.").max(1e9),
	minQty: number().finite().min(0, "La soglia non può essere negativa.").max(1e9),
	location: string().trim().max(80)
});
var saveItem = createServerFn({ method: "POST" }).validator(parse(itemInput)).middleware([authMiddleware]).handler(createSsrRpc("5a4055694e609ba9b7be325e8ca81e43b95e0ec7d4162b1fb55e5daea6cc46a3"));
var deleteItem = createServerFn({ method: "POST" }).validator(parse(object({
	warehouseId: idSchema,
	itemId: idSchema
}))).middleware([authMiddleware]).handler(createSsrRpc("73a77904415a580b55167c72f2822bb4f96ae11655220d1734c62e165a621682"));
var recordMove = createServerFn({ method: "POST" }).validator(parse(object({
	warehouseId: idSchema,
	itemId: idSchema,
	kind: _enum(["prelievo", "carico"]),
	qty: number().finite().gt(0, "Inserisci una quantità maggiore di zero.").max(1e9),
	note: string().trim().max(200)
}))).middleware([authMiddleware]).handler(createSsrRpc("487ac2a7917c0b03f5e6e97a5e0b3399d0baa327f6aaf2dc7e5a7143a67e016d"));
var listMovements = createServerFn({ method: "POST" }).validator(parse(object({
	warehouseId: idSchema,
	itemId: string().trim().max(80).nullable()
}))).middleware([authMiddleware]).handler(createSsrRpc("00266f1e36e6de7112365a85e93a3bfe242ccf722ee67b161179f3e143134ec8"));
var listAlerts = createServerFn({ method: "POST" }).validator(parse(object({ warehouseId: idSchema }))).middleware([authMiddleware]).handler(createSsrRpc("bc03e088f3f7a8d5bbdac3a3513b105e3aac34be30a860b8eb0adc4f4e7141ee"));
var ackAlerts = createServerFn({ method: "POST" }).validator(parse(object({ warehouseId: idSchema }))).middleware([authMiddleware]).handler(createSsrRpc("7e20b3eec38fd8ca91038f6a9d8cda081fdafe160d0cdd9a3b0a6982d6507911"));
//#endregion
export { joinWarehouse as a, listItems as c, listWarehouses as d, lookupItem as f, updateNotifyEmail as h, deleteWarehouse as i, listMembers as l, saveItem as m, createWarehouse as n, leaveWarehouse as o, recordMove as p, deleteItem as r, listAlerts as s, ackAlerts as t, listMovements as u };
