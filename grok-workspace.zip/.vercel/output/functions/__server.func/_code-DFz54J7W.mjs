import { o as __toESM } from "./_runtime.mjs";
import { n as require_react } from "./_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as Navigate } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "./_libs/radix-ui__react-context+react.mjs";
import { r as WAREHOUSE_KEY } from "./_ssr/format-D4Bv_-7v.mjs";
import { n as Route$1 } from "./_ssr/router-BErZIEja.mjs";
import { i as useCurrentUserState, t as BootScreen } from "./_ssr/login-panel-J-UwXrSk.mjs";
import { a as joinWarehouse } from "./_ssr/api-C9GurCZt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_code-DFz54J7W.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function JoinPage() {
	const { code } = Route$1.useParams();
	const { user, isPending } = useCurrentUserState();
	const started = (0, import_react.useRef)(false);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (isPending || !user || started.current) return;
		started.current = true;
		joinWarehouse({ data: { code } }).then((warehouse) => {
			localStorage.setItem(WAREHOUSE_KEY, warehouse.id);
			window.location.assign("/");
		}).catch((caught) => {
			started.current = false;
			setError(caught instanceof Error ? caught.message : "Codice non valido.");
		});
	}, [
		code,
		isPending,
		user
	]);
	if (isPending || user && !error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, { label: "Entro nel magazzino…" });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, {
		to: "/login",
		search: { next: `/join/${code}` }
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-screen w-full max-w-xl flex-col justify-center gap-4 px-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "eyebrow",
				children: "Codice"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-semibold tracking-tight",
				children: "Non riesco a entrare"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "note note-danger",
				role: "alert",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				className: "btn btn-primary",
				href: "/",
				children: "Torna a Stiva"
			})
		]
	});
}
//#endregion
export { JoinPage as component };
