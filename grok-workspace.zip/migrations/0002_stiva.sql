-- Shared warehouse, stock, movements, and per-member low-stock alerts.

create table if not exists warehouses (
  id text primary key,
  name text not null,
  join_code text not null unique,
  created_by text not null,
  notify_email text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists warehouse_members (
  warehouse_id text not null references warehouses (id) on delete cascade,
  user_id text not null,
  email text not null default '',
  display_name text not null default '',
  role text not null default 'member' check (role in ('owner', 'member')),
  created_at timestamptz not null default now(),
  primary key (warehouse_id, user_id)
);

create index if not exists warehouse_members_user_idx on warehouse_members (user_id);

create table if not exists items (
  id text primary key,
  warehouse_id text not null references warehouses (id) on delete cascade,
  code text not null,
  name text not null,
  unit text not null default 'pz',
  qty double precision not null default 0 check (qty >= 0),
  min_qty double precision not null default 0 check (min_qty >= 0),
  location text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (warehouse_id, code)
);

create index if not exists items_warehouse_idx on items (warehouse_id);

create table if not exists movements (
  id text primary key,
  warehouse_id text not null references warehouses (id) on delete cascade,
  item_id text not null,
  item_code text not null,
  item_name text not null,
  user_id text not null,
  actor_name text not null default '',
  kind text not null check (kind in ('prelievo', 'carico', 'rettifica')),
  qty double precision not null,
  qty_before double precision not null,
  qty_after double precision not null,
  note text not null default '',
  created_at timestamptz not null default now()
);

create index if not exists movements_wh_idx on movements (warehouse_id, created_at desc);

create table if not exists alerts (
  id text primary key,
  warehouse_id text not null references warehouses (id) on delete cascade,
  item_id text not null,
  item_code text not null,
  item_name text not null,
  unit text not null default 'pz',
  qty_after double precision not null,
  min_qty double precision not null,
  message text not null,
  recipients text not null default '',
  created_at timestamptz not null default now()
);

create index if not exists alerts_wh_idx on alerts (warehouse_id, created_at desc);

create table if not exists alert_receipts (
  alert_id text not null references alerts (id) on delete cascade,
  user_id text not null,
  acked_at timestamptz,
  primary key (alert_id, user_id)
);

create index if not exists alert_receipts_user_idx on alert_receipts (user_id);
